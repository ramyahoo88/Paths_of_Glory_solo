# General Staff v0.7.2 audit evidence

Reviewed code: `ramyahoo88/Paths_of_Glory_solo`, commit `87e7b3911e507713b57ed2fce1763e11200eee8e`. Audit-only branch head at review: `dd4f2b5d035a05b2f5087017cf16378222e1747e`. Engine: `rally-the-troops/paths-of-glory`, pin `c58b0b4` plus `sim/engine_hook.js`.

No game code was changed for this audit. Test-only wrappers expose engine functions or observe decisions. The engine and publisher files are not included. Fetch them through the project's normal `sim/setup_engine.sh`. Node is required for the JavaScript tests; Python plus PyMuPDF is required for print-checks.py. The PDF report builder additionally needs ReportLab and DejaVu fonts.

## Reproduction layout

Put the reviewed checkout in a directory named `source`, beside this extracted `evidence` directory. Run the engine setup there. Most new scripts also accept `GS_ROOT=/absolute/path/to/checkout`; the three carried-forward reproductions use `../source` explicitly. Run the commands listed in the report from the parent of `evidence`.

## Files and interpretations

- `build-check.json`: all four separate-path HTML byte comparisons.
- `source-sha256.json`: downloaded source fingerprints. Shipped source artifacts were verified against repository Git blob hashes.
- `print-checks.py`, `print-results.json`, `rendered/`: shipped-content parity, exact PDF fragmentation assertions, and all 22 rendered player-document pages.
- `app-state-checks.cjs`, `app-state-results.json`: unmodified shipped JavaScript with DOM/storage doubles. **Not a browser test.** This verifies several normal cases and deliberately reproduces defects.
- `companion-after-18-draws.json`, `companion-invalid-side.json`: localStorage fixtures. The current app has no import feature. To reproduce in a developer browser, set the stringified fixture at key `gs-companion` and reload; preserve your own session first.
- `multinational-proof.cjs`, `multinational-proof.json`, `multinational-state.json`: minimal legal-participation counterexample, execution trace and nearby common-stack control. The fixture is intentionally isolated and is not claimed to be a reached campaign position.
- `event-proof.cjs`, `event-proof.json`, `event-state-*.json`: rerun seed 951000 to reproduce Landwehr, War in Africa, trench selection and abandoned movement. The movement trace and board snapshot are inside event-proof.json.
- `fix-checks.cjs`, `fix-checks.json`: 864 arithmetic comparisons plus original defects, exception injection and step-cap reporting.
- `mo-proof.cjs`, `mo-selected-summary.json`: original four mandate-credit seeds. The empty JSON array means no bad selected-unit MO plans were found.
- `boundary-checks.cjs`, `boundary-results.json`: explicit native-rule assertions for setup, losses, reserve exhaustion, supply and scoring. Uses the unmodified engine with test exports, not a replacement rules engine.
- `strategy-sweep.cjs`, `strategy-games.json`, `strategy-summary.json`: all 72 purposeful stress games and exact configurations. Profiles share the bot machinery. 761 choice-bearing and 410 forced visits had no named state handler. A successful completed game can still contain an operation repair.
- `representative-campaign.json`: seed 980000, released AP against pressure CP; initial state, round choices and terminal state.
- `hidden-info-check.cjs`, `hidden-info-results.json`: seed 981000; forbidden hidden-state reads throw during every decision, after normal engine view generation. The engine may legitimately use private state outside bot decisions.
- `sample-rebuilt.md`: current two-turn seed-2 worked example, byte-identical to the shipped example.
- `official-card-sources.json`: source URLs/hashes for the two legacy manifests consulted. Their PDFs/images are not redistributed.
- `coverage-limit.txt`: browser and PDF rebuild limits.

Scripts that reproduce a bug intentionally assert its current wrong result. A passing reproduction is not a release pass. Update those expectations after implementing a fix.

## Separate build reproduction

Preserve the checkout, copy it to another directory, and run `node app/build_app.js` and `NO_PDF=1 node print/build.js` in that copy. Compare each resulting HTML with the original. Full PDF regeneration needs the project's Chrome/pandoc toolchain and an actual layout inspection; the audit did not claim to regenerate PDFs.

## Claims deliberately not made

No real-browser, mobile, accessibility, human-strength or timed physical-play pass. No remeasurement of the published 600-game balance or handicap effect. No exhaustive certification of the Rally the Troops engine. No edits to production or native game rules.
