// Fail immediately if a decision reads the opponent's hand, either strategy deck, or the engine RNG state.
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../source'));
const R=require(path.join(root,'engine/rules.js')),{Bot,ROLE,legal}=require(path.join(root,'sim/bot.js'));
const seed=981000;let g=R.setup(seed,'Historical',{no_supply_warnings:true}),steps=0;
const P=Object.fromEntries(['ap','cp'].map(s=>[ROLE[s],new Bot(s,seed)])),states={};
while(g.state!=='game_over'&&steps<60000){
 const role=g.active,b=P[role],v=R.view(g,role),saved=[];states[g.state]=(states[g.state]||0)+1;
 for(const [obj,key] of [[g[b.enemy],'hand'],[g.ap,'deck'],[g.cp,'deck'],[g,'seed']]){
  saved.push([obj,key,Object.getOwnPropertyDescriptor(obj,key)]);Object.defineProperty(obj,key,{configurable:true,get(){throw Error('Hidden information read: '+key+' in '+g.state)}});
 }
 let a;try{a=b.decide(g,v);}finally{for(const [o,k,d] of saved)Object.defineProperty(o,k,d);}
 assert(legal(v.actions,a));g=R.action(g,role,...a);steps++;if(g.log.length>500)g.log=g.log.slice(-100);
}
assert.equal(g.state,'game_over');
const result={seed,steps,result:g.result,victory:g.victory,turn:g.turn,vp:g.vp,states,hiddenReads:0,scope:'Decision-time checks after engine view generation; does not prove every unvisited handler or human operator hides the bot hand.'};
fs.writeFileSync(path.join(__dirname,'hidden-info-results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
