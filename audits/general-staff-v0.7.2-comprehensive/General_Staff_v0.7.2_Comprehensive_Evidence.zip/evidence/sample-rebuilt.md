# Sample turns

These are the first 2 turns of a simulated campaign (seed 2), with **General Staff playing both sides**. Each paragraph is one bot action round: the Staff card drawn, the step of the action-round procedure (rules §3) that decided it, the card played, and for Operations the planned attacks (with their Edge) and moves.

Use it to check your reading of the procedure: with the same hand (shown, with each card's OPS value in brackets) and the same Staff card, see whether you reach the same step. The engine resolved all combat, so dice results are not shown. Positions differ in your own games.

*How to read the entries*

* **Step** names match rules §3: *Forced play*, *MO: last chance*, *Urgent event*, *MO*, *Crisis*, *Rebuild* (Allies only), *Plan* (with the option that fired), *Fallback*.
* **Attacks** list the target, the attacking spaces and the Edge (before bonuses). "MO" marks an attack that satisfies the mandated offensive.
* **Moves** list the Move-list entries the Operation paid for, in the order planned (highest Move value first).

---

**Turn 1, Central Powers bot, round 1.** Hand: Guns of August [3], German Reinforcements (GE 10) [4], Von Francois [2], Landwehr [2], Reichstag Truce [4], Entrench [3], Severe Weather [2], Wireless Intercepts [2]. Staff card 17: front 6, Press, plan Event, tie North. Step: *Forced play*. Plays **Guns of August** as an Event.

**Turn 1, Allied bot, round 1.** Hand: British Reinforcements (BR 2) [4], Severe Weather [2], Rape of Belgium [4], Putnik [2], Moltke [3], Russian Reinforcements (2 corps) [2], Entrench [3], French Reinforcements (FR 10) [3]. Staff card 17: front 6, Press, plan Event, tie North. Step: *Urgent event*. Plays **Rape of Belgium** as an Event.

**Turn 1, Central Powers bot, round 2.** Hand: German Reinforcements (GE 10) [4], Von Francois [2], Landwehr [2], Reichstag Truce [4], Entrench [3], Severe Weather [2], Wireless Intercepts [2]. Staff card 1: front 1, Assault, plan Event, tie North. Step: *Urgent event*. Plays **Reichstag Truce** as an Event.

**Turn 1, Allied bot, round 2.** Hand: British Reinforcements (BR 2) [4], Severe Weather [2], Putnik [2], Moltke [3], Russian Reinforcements (2 corps) [2], Entrench [3], French Reinforcements (FR 10) [3]. Staff card 5: front 2, Press, plan Ops, tie North. Step: *Urgent event*. Plays **Moltke** as an Event.

**Turn 1, Central Powers bot, round 3.** Hand: German Reinforcements (GE 10) [4], Von Francois [2], Landwehr [2], Entrench [3], Severe Weather [2], Wireless Intercepts [2]. Staff card 16: front 6, Assault, plan Ops, tie South. Step: *Urgent event*. Plays **Landwehr** as an Event.

**Turn 1, Allied bot, round 3.** Hand: British Reinforcements (BR 2) [4], Severe Weather [2], Putnik [2], Russian Reinforcements (2 corps) [2], Entrench [3], French Reinforcements (FR 10) [3]. Staff card 4: front 2, Assault, plan Logistics, tie South. Step: *Rebuild*. Plays **Entrench** for RP.

**Turn 1, Central Powers bot, round 4.** Hand: German Reinforcements (GE 10) [4], Von Francois [2], Entrench [3], Severe Weather [2], Wireless Intercepts [2]. Staff card 12: front 4, Hold, plan Ops, tie South. Step: *Crisis*. Plays **Wireless Intercepts** for Operations. Attacks: Brussels from Sedan (Edge +1.2).

**Turn 1, Allied bot, round 4.** Hand: British Reinforcements (BR 2) [4], Severe Weather [2], Putnik [2], Russian Reinforcements (2 corps) [2], French Reinforcements (FR 10) [3]. Staff card 3: front 1, Hold, plan Ops, tie North. Step: *Crisis*. Plays **Putnik** for Operations. Attacks: Sedan from Verdun (Edge +1.5); Czernowitz from Kamenets-Podolski (Edge +2).

**Turn 1, Central Powers bot, round 5.** Hand: German Reinforcements (GE 10) [4], Von Francois [2], Entrench [3], Severe Weather [2]. Staff card 8: front 3, Press, plan Event, tie South. Step: *Plan: Attack*. Plays **Entrench** for Operations. Attacks: Antwerp from Brussels (Edge +1); Belgrade from Novi Sad + Timisvar (Edge +0.5).

**Turn 1, Allied bot, round 5.** Hand: British Reinforcements (BR 2) [4], Severe Weather [2], Russian Reinforcements (2 corps) [2], French Reinforcements (FR 10) [3]. Staff card 13: front 5, Assault, plan Logistics, tie North. Step: *Plan: Logistics*. Plays **Severe Weather** for RP.

**Turn 1, Central Powers bot, round 6.** Hand: German Reinforcements (GE 10) [4], Von Francois [2], Severe Weather [2]. Staff card 10: front 4, Assault, plan Event, tie South. Step: *Plan: Attack*. Plays **German Reinforcements (GE 10)** for Operations. Attacks: Antwerp from Brussels (Edge +3); Nancy from Metz + Strasbourg (Edge +0.6). Moves: capture Sedan → Cambrai.

**Turn 1, Allied bot, round 6.** Hand: British Reinforcements (BR 2) [4], Russian Reinforcements (2 corps) [2], French Reinforcements (FR 10) [3]. Staff card 1: front 1, Assault, plan Event, tie North. Step: *Plan: Attack*. Plays **French Reinforcements (FR 10)** for Operations. Attacks: Cambrai from Calais (Edge +0.4); Tarnopol from Dubno + Kamenets-Podolski (Edge +1.5).

**Turn 2, Central Powers bot, round 1.** Hand: Von Francois [2], Severe Weather [2], SUD Army [3], Oberost [2], German Reinforcements (GE 9) [3], Race to the Sea [3], Austria-Hungary Reinforcements (AH 7) [4], Falkenhayn [4]. Staff card 7: front 3, Assault, plan Ops, tie North. Step: *Urgent event*. Plays **German Reinforcements (GE 9)** as an Event.

**Turn 2, Allied bot, round 1.** Hand: British Reinforcements (BR 2) [4], Russian Reinforcements (2 corps) [2], Withdrawal [2], Russian Reinforcements (RU 9, RU 10) [3], Blockade [4], British Reinforcements (BR 1) [4], Pleve [2], Russian Reinforcements (RU 11) [3]. Staff card 2: front 1, Press, plan Logistics, tie South. Step: *Urgent event*. Plays **Blockade** as an Event.

**Turn 2, Central Powers bot, round 2.** Hand: Von Francois [2], Severe Weather [2], SUD Army [3], Oberost [2], Race to the Sea [3], Austria-Hungary Reinforcements (AH 7) [4], Falkenhayn [4]. Staff card 2: front 1, Press, plan Logistics, tie South. Step: *Urgent event*. Plays **Austria-Hungary Reinforcements (AH 7)** as an Event.

**Turn 2, Allied bot, round 2.** Hand: British Reinforcements (BR 2) [4], Russian Reinforcements (2 corps) [2], Withdrawal [2], Russian Reinforcements (RU 9, RU 10) [3], British Reinforcements (BR 1) [4], Pleve [2], Russian Reinforcements (RU 11) [3]. Staff card 9: front 3, Hold, plan Logistics, tie North. Step: *Urgent event*. Plays **Russian Reinforcements (RU 9, RU 10)** as an Event.

**Turn 2, Central Powers bot, round 3.** Hand: Von Francois [2], Severe Weather [2], SUD Army [3], Oberost [2], Race to the Sea [3], Falkenhayn [4]. Staff card 4: front 2, Assault, plan Logistics, tie South. Step: *Urgent event*. Plays **Oberost** as an Event.

**Turn 2, Allied bot, round 3.** Hand: British Reinforcements (BR 2) [4], Russian Reinforcements (2 corps) [2], Withdrawal [2], British Reinforcements (BR 1) [4], Pleve [2], Russian Reinforcements (RU 11) [3]. Staff card 15: front 5, Hold, plan Event, tie North. Step: *Urgent event*. Plays **British Reinforcements (BR 2)** as an Event.

**Turn 2, Central Powers bot, round 4.** Hand: Von Francois [2], Severe Weather [2], SUD Army [3], Race to the Sea [3], Falkenhayn [4]. Staff card 6: front 2, Hold, plan Event, tie South. Step: *Urgent event*. Plays **Falkenhayn** as an Event.

**Turn 2, Allied bot, round 4.** Hand: Russian Reinforcements (2 corps) [2], Withdrawal [2], British Reinforcements (BR 1) [4], Pleve [2], Russian Reinforcements (RU 11) [3]. Staff card 14: front 5, Press, plan Ops, tie South. Step: *MO*. Plays **Russian Reinforcements (RU 11)** for Operations. Attacks: Stanislau from Tarnopol (Edge +3.5, MO); Tarnow from Ivangorod (Edge +0, MO); Cambrai from Calais (Edge +0.7).

**Turn 2, Central Powers bot, round 5.** Hand: Von Francois [2], Severe Weather [2], SUD Army [3], Race to the Sea [3]. Staff card 15: front 5, Hold, plan Event, tie North. Step: *MO: last chance*. Plays **Race to the Sea** for Operations. Attacks: Lublin from Przemysl (Edge +0, MO); Belgrade from Novi Sad (Edge -0.8, MO); Ivangorod from Tarnow (Edge -0.5, MO).

**Turn 2, Allied bot, round 5.** Hand: Russian Reinforcements (2 corps) [2], Withdrawal [2], British Reinforcements (BR 1) [4]. Staff card 10: front 4, Assault, plan Event, tie South. Step: *Rebuild*. Plays **Withdrawal** for RP.

**Turn 2, Central Powers bot, round 6.** Hand: Von Francois [2], Severe Weather [2], SUD Army [3]. Staff card 9: front 3, Hold, plan Logistics, tie North. Step: *Crisis*. Plays **Von Francois** for Operations. Attacks: Grodno from Insterberg (Edge +3.2). Moves: capture Brussels → Antwerp.

**Turn 2, Allied bot, round 6.** Hand: Russian Reinforcements (2 corps) [2], British Reinforcements (BR 1) [4]. Staff card 7: front 3, Assault, plan Ops, tie North. Step: *Plan: Attack*. Plays **Russian Reinforcements (2 corps)** for Operations. Attacks: Uzhgorod from Stanislau (Edge +3.2). Moves: capture Lutsk → Lemberg.
