// Minimal rules-engine position. Individual legal attackers are not necessarily a legal group.
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../source'));
const R=require(path.join(root,'engine/rules.js')),B=require(path.join(root,'sim/board.js')),{Bot}=require(path.join(root,'sim/bot.js'));
function position(joined){
 let g=R.setup(987654,'Historical',{no_supply_warnings:true});g.location.fill(0);g.reduced=[32];g.cp.trenches=[];g.ap.mo='none';g.ap.actions=[];g.turn=3;g.active='Allied Powers';g.state='action_phase';
 g.location[32]=B.S('Verdun');g.location[42]=B.S(joined?'Verdun':'Nancy');g.location[68]=B.S('Metz');g.ap.hand=[4];
 R.__with(g,A=>A.update_supply());return g;
}
function bot(){let b=new Bot('ap',987654);b.dir={id:3,n:1,stance:'H',plan:'L',tie:'N'};return b;}
let g=position(false),b=bot(),proof={seed:987654,fixture:'Reduced FR 1 in Verdun; full BR 1 in Nancy; full GE corps in Metz, intact fort 3, no defending trench. Others removed from the minimal fixture; standard control remains. Turn 3; AP Hold Staff card; 2 OPS; no MO.'};
fs.writeFileSync(path.join(__dirname,'multinational-state.json'),JSON.stringify(g,null,2)+'\n');
proof.eligibility=R.__with(g,A=>({individual:[32,42].map(p=>({unit:p,supplied:A.is_unit_supplied(p),targets:A.get_attackable_spaces([p])})),combined:A.get_attackable_spaces([32,42])}));
assert(proof.eligibility.individual.every(x=>x.supplied&&x.targets.includes(B.S('Metz'))));assert.deepEqual(proof.eligibility.combined,[]);
b.plan=R.__with(g,A=>b.planOps(A,2));proof.plan=JSON.parse(JSON.stringify(b.plan));assert.equal(b.plan.attacks[0].target,B.S('Metz'));assert.equal(b.plan.cost,2);
g=R.action(g,g.active,'play_ops',4);proof.trace=[];
for(let i=0;i<20;i++){
 const v=R.view(g,g.active),a=b.decide(g,v);proof.trace.push(JSON.parse(JSON.stringify({state:g.state,action:a,selected:g.attack?.pieces,offered:v.actions})));
 if(g.state==='choose_attackers'&&a[0]==='space'){
  const actual=R.__with(g,A=>b.evalAttack(A,g.attack.pieces,a[1]));
  proof.actual={units:g.attack.pieces,edge:actual.edge,score:actual.edge+proof.plan.attacks[0].score-proof.plan.attacks[0].edge,threshold:b.minEdge()};
  assert.deepEqual(g.attack.pieces,[32]);assert(proof.actual.score<b.minEdge()-0.5);break;
 }g=R.action(g,g.active,...a);
}
assert(proof.actual);
const nearby=position(true),b2=bot();proof.nearbyCommonStack=R.__with(nearby,A=>({combinedTargets:A.get_attackable_spaces([32,42]),plan:b2.planOps(A,2)}));assert(proof.nearbyCommonStack.combinedTargets.includes(B.S('Metz')));
fs.writeFileSync(path.join(__dirname,'multinational-proof.json'),JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify(proof,null,2));
