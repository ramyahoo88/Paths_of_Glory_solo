// Focused engine boundaries using the unmodified pinned code plus read-only test exports.
// Expected outcomes are specified from GMT Living Rules, not copied from the bot.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),{createRequire}=require('module');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../source')),file=path.join(root,'engine/rules.js');
const req=createRequire(file),moduleCopy={exports:{}};
vm.compileFunction(fs.readFileSync(file,'utf8')+'\nexports.audit={get_game_result_by_vp,eliminate_piece,get_loss_option_units,apply_defender_loss,goto_war_status_phase};',['require','module','exports','__filename','__dirname'])(req,moduleCopy,moduleCopy.exports,file,path.dirname(file));
const R=moduleCopy.exports,B=require(path.join(root,'sim/board.js')),{Bot}=require(path.join(root,'sim/bot.js'));
const results={checks:[]};function run(label,fn){fn();results.checks.push(label);}
const setup=()=>R.setup(983001,'Historical',{no_supply_warnings:true});
run('Historical setup: 8 cards each; Guns of August held by CP; no optional cards',()=>{let g=setup();assert.equal(g.ap.hand.length,8);assert.equal(g.cp.hand.length,8);assert(g.cp.hand.includes(66));assert(g.ap.hand.every(c=>c<=55));assert(g.cp.hand.every(c=>c>=66&&c<=120));});
run('Historical final scoring: AP wins 12 VP, CP wins 13; with Treaty AP wins 10, CP wins 11',()=>{for(const [vp,treaty,winner] of [[12,false,'ap'],[13,false,'cp'],[10,true,'ap'],[11,true,'cp']]){let g=setup();g.vp=vp;g.events.reinforcements=[43,47];g.events.fall_of_the_tsar=1;if(treaty)g.events.treaty_of_brest_litovsk=1;assert.equal(R.__with(g,()=>R.audit.get_game_result_by_vp()),winner);assert.equal(g.vp,vp);}});
run('Historical final modifiers: two unplayed US army cards +2; no Fall of the Tsar -2',()=>{let g=setup();g.vp=12;g.events.fall_of_the_tsar=1;R.__with(g,()=>R.audit.get_game_result_by_vp());assert.equal(g.vp,14);g=setup();g.vp=12;g.events.reinforcements=[43,47];R.__with(g,()=>R.audit.get_game_result_by_vp());assert.equal(g.vp,10);});
run('Automatic victory at 0/20 VP ends immediately without final US/Tsar adjustment',()=>{for(const [vp,winner] of [[0,'Allied Powers'],[20,'Central Powers']]){let g=setup();g.turn=3;g.vp=vp;g.ap.mo=g.cp.mo='none';g.events.fall_of_the_tsar=1;R.__with(g,()=>R.audit.goto_war_status_phase());assert.equal(g.state,'game_over');assert.equal(g.result,winner);assert.equal(g.vp,vp);}});
run('Exhausted reserve: eliminated normal army is permanent without replacement corps; recoverable with one',()=>{
 for(const corps of [false,true]){let g=setup();g.location.fill(0);g.active='Allied Powers';g.location[32]=B.S('Nancy');g.reduced=[32];
 const frCorp=B.data.pieces.findIndex(p=>p&&p.nation==='fr'&&p.type==='corps');if(corps)g.location[frCorp]=R.__api.AP_RESERVE_BOX;
 R.__with(g,A=>{A.update_supply();assert(A.is_unit_supplied(32));R.audit.eliminate_piece(32,false);assert.equal(g.location[32],corps?A.AP_ELIMINATED_BOX:A.PERM_ELIMINATED_BOX);});
 }
});
run('7-loss boundary: two full 3-LF French armies with no reserve must eliminate one, not flip both',()=>{results.lossPaths=[];for(const first of [32,33]){let g=setup();g.location.fill(0);g.active='Allied Powers';g.location[32]=g.location[33]=B.S('Nancy');g.reduced=[];g.attack={space:B.S('Nancy'),attacker:'cp',defender:'ap',pieces:[],defender_losses:7,defender_losses_taken:0,attacker_losses_taken:0,defender_loss_pieces:[],combat_cards:[]};
 R.__with(g,A=>{A.update_supply();assert(R.audit.get_loss_option_units(true,7,[32,33],0).includes(first));R.audit.apply_defender_loss(first);const next=R.audit.get_loss_option_units(true,4,[32,33],0);assert.deepEqual(next,[first]);R.audit.apply_defender_loss(first);assert.equal(g.location[first],A.PERM_ELIMINATED_BOX);assert(!g.reduced.includes(first===32?33:32));results.lossPaths.push([first,first]);});}
});
run('Supply: isolated German army in CP-held Paris cannot be an attacker; supplied army in Essen remains supplied',()=>{let g=setup();g.location.fill(0);let paris=B.S('Paris');g.location[1]=paris;g.control[paris>>5]|=1<<(paris&31);g.location[2]=B.S('Essen');R.__with(g,A=>{A.update_supply();assert(!A.is_unit_supplied(1));assert(A.is_unit_supplied(2));assert(g.oos_pieces.includes(1));});});
run('Staff Tie: North/South reverse the choice for unequal north-south coordinates',()=>{const b=new Bot('ap',1);b.dir={tie:'N'};const north=b.tie(B.S('Antwerp'),B.S('Brussels'));b.dir={tie:'S'};const south=b.tie(B.S('Antwerp'),B.S('Brussels'));assert(north<0&&south>0);});
fs.writeFileSync(path.join(__dirname,'boundary-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
