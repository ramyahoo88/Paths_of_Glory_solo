// Exercises the unmodified shipped script in Node's VM, with small DOM/storage doubles.
// These are control-handler tests, NOT browser/render/accessibility tests.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../source'));
const html=fs.readFileSync(path.join(root,'app/General_Staff_Companion.html'),'utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
function boot(saved, failWrite=false){
 const nodes={}; for(const m of html.matchAll(/\bid="([^"]+)"/g)) nodes[m[1]]={value:'',checked:false,innerHTML:'',textContent:'',classList:{toggle(){}}};
 for(const m of html.matchAll(/<input\b([^>]+)>/g)){const id=m[1].match(/id="([^"]+)"/);if(id){nodes[id[1]].value=(m[1].match(/value="([^"]*)"/)||[])[1]||'';nodes[id[1]].checked=/\bchecked\b/.test(m[1]);}}
 for(const m of html.matchAll(/<select\b[^>]*id="([^"]+)"[^>]*>\s*<option(?: value="([^"]*)")?[^>]*>([^<]+)/g)) nodes[m[1]].value=m[2]??m[3];
 const tabs=['obj','front','ev'].map(t=>({dataset:{t},classList:{toggle(){}}}));
 const storage={value:saved??null};let rnd=123456789;
 const crypto={getRandomValues(a){rnd=(Math.imul(1664525,rnd)+1013904223)>>>0;a[0]=rnd;return a;}};
 const context=vm.createContext({document:{getElementById:id=>nodes[id],querySelectorAll:()=>tabs},localStorage:{getItem:()=>storage.value,setItem:(k,v)=>{if(failWrite)throw Error('QuotaExceededError');storage.value=v;}},window:{crypto},crypto,Uint32Array,Math,JSON});
 let error=null;try{vm.runInContext(script,context);}catch(e){error=e.message;}
 return {nodes,storage,error,run:s=>vm.runInContext(s,context),state:()=>JSON.parse(vm.runInContext('JSON.stringify(S)',context))};
}
const results={method:'Unmodified shipped JavaScript; VM DOM/storage doubles; no browser execution',passes:[],findings:{}};
let a=boot();assert.equal(a.error,null);results.passes.push('Clean first launch: 18 cards and no active card');
for(let i=0;i<18;i++)a.nodes.draw.onclick();let s=a.state();assert.equal(new Set(s.discard).size,18);assert.equal(s.deck.length,0);results.passes.push('First cycle contains every Staff card exactly once');
const before=JSON.stringify(s);a.nodes.draw.onclick();a.nodes.undo.onclick();const after=JSON.stringify(a.state());
assert.notEqual(before,after);results.findings.undoReshuffle={expected:{deck:0,discard:18},observed:{deck:a.state().deck.length,discard:a.state().discard.length},sameCurrent:a.state().cur===s.cur};
fs.writeFileSync(path.join(__dirname,'companion-after-18-draws.json'),before+'\n');
a=boot(before);assert.deepEqual(a.state(),JSON.parse(before));results.passes.push('Valid saved session reloads with deck, current card and draw history intact');
for(let i=0;i<18;i++)a.nodes.undo.onclick();assert.equal(a.state().cur,null);assert.equal(a.state().deck.length,18);results.passes.push('Undo all 18 ordinary draws restores initial order and current-card state');
a=boot();let displays=0;
for(const side of ['ap','cp'])for(const lvl of ['mobilization','limited','total'])for(let id=1;id<=18;id++){
 a.run(`S.side=${JSON.stringify(side)};S.lvl=${JSON.stringify(lvl)};S.cur=${id};render()`);
 assert(!a.nodes.card.innerHTML.includes('undefined'));assert(a.nodes.card.innerHTML.includes(`Card ${id}/18`));displays++;
}results.passes.push(displays+' side/commitment/card displays have valid front, stance and card identity');
function inputs(values){for(const [k,v] of Object.entries(values)){if(typeof v==='boolean')a.nodes[k].checked=v;else a.nodes[k].value=String(v);a.nodes[k].oninput?.();}}
a.run("S.side='ap';S.cur=1;render()");inputs({acf:0,aarmy:false,dcf:16,darmy:true,dunits:true,fort:0,terr:0,tr:2,bmo:6,bfront:0,bobj:false,bnear:false,bvp:false,boos:false});
results.findings.lateMO={observed:a.nodes.edge.innerHTML,expected:'Make the first qualifying, unmet MO attack in rounds 5–6, regardless of Score (§5.4).'};
assert(a.nodes.edge.innerHTML.includes('too weak'));assert(a.nodes.edge.innerHTML.includes('Score +0.00'));
inputs({bmo:2.5});assert(a.nodes.edge.innerHTML.includes('too weak'));results.passes.push('Nearby early-round MO remains below stance threshold');
a.run("S.side='cp';S.cur=3;render()");inputs({acf:8,aarmy:true,dcf:0,darmy:true,dunits:false,fort:2,terr:0,tr:2,bmo:0});const emptyCorrect=a.nodes.edge.innerHTML;
inputs({dcf:12});const emptyStale=a.nodes.edge.innerHTML;
assert(emptyCorrect.includes('— attack'));assert(emptyStale.includes('too weak'));
results.findings.emptyFortStaleCF={expected:'Defender CF ignored when units-in-space is off; only fort CF fires.',zeroDefenderInput:emptyCorrect,staleDefenderInput:emptyStale};
inputs({dcf:0,dunits:true,fort:0,darmy:false,tr:0});assert(a.nodes.edge.innerHTML.includes('defender 0.3'));results.passes.push('GS-02 regression: an occupied 0-CF defense fires on Corps 0');
inputs({acf:9,aarmy:true,dcf:12,darmy:true,fort:0,dunits:true,tr:0,terr:0,bfront:-0.75,bobj:false,bnear:true,bvp:true,bmo:0});
// The common precision arithmetic is checked exhaustively in prior fix-checks.cjs.
const corrupt={side:'invalid-side',lvl:'mobilization',deck:[1,2],discard:[3],hist:[],cur:3};
const c=boot(JSON.stringify(corrupt));assert(c.error);results.findings.invalidSave={input:corrupt,error:c.error,retained:JSON.parse(c.storage.value)};
fs.writeFileSync(path.join(__dirname,'companion-invalid-side.json'),JSON.stringify(corrupt,null,2)+'\n');
const duplicate={side:'cp',lvl:'mobilization',deck:Array(18).fill(1),discard:[],hist:[],cur:null};const d=boot(JSON.stringify(duplicate));d.nodes.draw.onclick();d.nodes.draw.onclick();assert.deepEqual(d.state().discard,[1,1]);results.findings.invalidSave.duplicateCardsAccepted=true;
const h=boot(JSON.stringify({side:'cp',lvl:'mobilization',deck:[1],discard:[2],hist:['invalid JSON'],cur:2}));let undoError;try{h.nodes.undo.onclick()}catch(e){undoError=e.message}assert(undoError);results.findings.invalidSave.undoHistoryError=undoError;
const malformed=boot('{');assert.equal(malformed.error,null);assert.equal(malformed.state().deck.length,18);results.passes.push('Malformed JSON resets to a new deck (silently)');
const q=boot(null,true);q.nodes.draw.onclick();assert.equal(q.error,null);assert.equal(q.storage.value,null);results.findings.silentSaveFailure={expected:'Visible notice when session cannot be saved',observed:'Draw works and no error is shown, but nothing is persisted'};
const e=boot();e.nodes.evq.value='55';e.nodes.evq.oninput();assert(e.nodes.evlist.innerHTML.includes('Lloyd George'));e.nodes.side.onchange({target:{value:'ap'}});assert(e.nodes.evlist.innerHTML.includes('Over There'));results.passes.push('Card-number search and side switch select corresponding card 55');
fs.writeFileSync(path.join(__dirname,'app-state-results.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
