// Purposeful stress opponents; these share the General Staff machinery and are NOT human-strength estimates.
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../source'));
const R=require(path.join(root,'engine/rules.js')),{Bot,ROLE,legal}=require(path.join(root,'sim/bot.js'));
const profiles={
 pressure:s=>({fixedStance:'A',edgeShift:s==='ap'?0.5:-0.5,advance:'always',rpStep:0}),
 defensive:s=>({fixedStance:'H',edgeShift:s==='ap'?2.5:1.5,entrenchH:4,entrenchV:2,advance:'never',rpStep:3}),
 capture:s=>({captureV:6,fwdArmyV:3,gaps:true})
};
const n=+(process.env.N||12),start=+(process.env.START||980000),games=[];
for(const [profile,opts] of Object.entries(profiles))for(const testedSide of ['ap','cp'])for(let seed=start;seed<start+n;seed++){
 let g=R.setup(seed,'Historical',{no_supply_warnings:true}),steps=0,err=null,turn=0;
 const P=Object.fromEntries(['ap','cp'].map(s=>[ROLE[s],new Bot(s,seed,s===testedSide?{}:opts(s))]));
 const missing={},returns={},trace=[],vps=[],states={},firstSetup=JSON.parse(JSON.stringify(g));
 try{while(g.state!=='game_over'&&steps<60000){
  const role=g.active,b=P[role],v=R.view(g,role),state=g.state;
  states[state]=(states[state]||0)+1;
  if(g.turn!==turn){turn=g.turn;vps.push({turn,vp:g.vp,ws:{ap:g.ap.ws,cp:g.cp.ws}});}
  if(!b['s_'+state]){const meaningful=Object.entries(v.actions||{}).filter(([k,x])=>!['undo','propose_rollback','flag_supply_warnings','reset_phase'].includes(k)&&x!==0).reduce((a,[k,x])=>a+(Array.isArray(x)?x.length:1),0);const key=state+':'+(meaningful>1?'choice':'forced');missing[key]=(missing[key]||0)+1;}
  const a=b.decide(g,v);assert(legal(v.actions,a),state+' rejected action '+JSON.stringify(a));
  if(['action_phase','confirm_move_violations'].includes(state)) trace.push({step:steps,turn:g.turn,side:b.side,state,action:a,staff:b.dir,procedureStep:b.step,violations:v.violations});
  g=R.action(g,role,...a);steps++;if(g.log.length>500)g.log=g.log.slice(-200);
 }
 if(g.state!=='game_over')throw Error('Step cap');
 }catch(e){err=e.stack;}
 const r={profile,testedSide,seed,result:g.result,win:g.result===ROLE[testedSide],turn:g.turn,vp:g.vp,victory:g.victory,complete:g.state==='game_over'&&!err,err,steps,missedMO:{ap:g.ap.missed_mo.length,cp:g.cp.missed_mo.length},stats:{ap:P[ROLE.ap].stats,cp:P[ROLE.cp].stats},missing,states,vps};
 games.push(r);
 if(seed===start&&profile==='pressure'&&testedSide==='ap')fs.writeFileSync(path.join(__dirname,'representative-campaign.json'),JSON.stringify({setup:firstSetup,rounds:trace,final:g},null,2)+'\n');
 fs.writeFileSync(path.join(__dirname,'strategy-games.json'),JSON.stringify({n,start,profiles:Object.fromEntries(Object.entries(profiles).map(([k,f])=>[k,{ap:f('ap'),cp:f('cp')}])),games},null,2)+'\n');
 console.log(profile,testedSide,seed,r.result,r.complete?'complete':r.err);
}
