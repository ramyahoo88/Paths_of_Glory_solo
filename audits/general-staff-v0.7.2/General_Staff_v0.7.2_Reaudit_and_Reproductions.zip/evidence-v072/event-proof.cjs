// Read-only instrumentation of the shipped bot. No decision logic is replaced.
const fs = require('node:fs');
const R = require('../source-v072/engine/rules.js');
const { Bot, ROLE, legal } = require('../source-v072/sim/bot.js');
const B = require('../source-v072/sim/board.js');
const seed = 951000;
let g = R.setup(seed, 'Historical', { no_supply_warnings: true });
const players = Object.fromEntries(['ap', 'cp'].map(s => [ROLE[s], new Bot(s, seed)]));
const result = { seed, examples: {}, steps: 0 };
const recent = [];
function unitsAt(game, space) {
  return B.data.pieces.flatMap((p, id) => p && game.location[id] === space ? [{
    id, name: p.name, nation: p.nation, type: p.type, reduced: game.reduced.includes(id)
  }] : []);
}
while (g.state !== 'game_over' && result.steps < 60000) {
  const state = g.state, role = g.active, bot = players[role], view = R.view(g, role);
  const before = JSON.parse(JSON.stringify(g));
  let trench;
  if (state === 'place_event_trench' && !result.examples.eventTrench && view.actions.space?.length) {
    const fronts = R.__with(g, A => bot.frontsInOrder(A));
    const spaces = [...view.actions.space];
    const expected = [...spaces].sort((a, b) => fronts.indexOf(B.FRONT[a]) - fronts.indexOf(B.FRONT[b]) || bot.tie(a, b))[0];
    trench = { state, side: bot.side, turn: g.turn, staff: bot.dir, fronts,
      legalSpaces: spaces.map(id => ({ id, name: B.data.spaces[id].name, front: B.FRONT[id], y: B.ycoord(id) })),
      expected: { id: expected, name: B.data.spaces[expected].name } };
  }
  const action = bot.decide(g, view);
  if (!legal(view.actions, action)) throw Error('Illegal action ' + JSON.stringify(action));
  recent.push({ state, side: bot.side, action, actions: view.actions,
    move: before.move, planMove: bot.curMove ? JSON.parse(JSON.stringify(bot.curMove)) : null });
  if (recent.length > 12) recent.shift();
  let example;
  if (!result.examples[state] && ['landwehr', 'war_in_africa'].includes(state) && view.actions.piece?.length) {
    example = {
      state, side: bot.side, turn: g.turn, prompt: view.prompt,
      legalUnits: view.actions.piece.map(id => ({ id, name: B.data.pieces[id].name,
        type: B.data.pieces[id].type, space: B.data.spaces[before.location[id]]?.name,
        reduced: before.reduced.includes(id) })), action,
      beforeVP: before.vp, beforeReduced: before.reduced
    };
    fs.writeFileSync(__dirname + '/event-state-' + state + '-' + seed + '.json', JSON.stringify(before, null, 2) + '\n');
  }
  if (action[0] === 'reset_phase' && !result.examples.movementReset) {
    const from = bot.curMove.from, to = bot.curMove.to;
    example = { state, side: bot.side, turn: g.turn, round: g[bot.side].actions.length + 1,
      action, violations: view.violations, from: { id: from, name: B.data.spaces[from].name },
      to: { id: to, name: B.data.spaces[to].name }, beforeFrom: unitsAt(before, from),
      beforeTo: unitsAt(before, to), staff: bot.dir, recent: [...recent] };
  }
  if (trench) {
    example = { ...trench, action, actual: B.data.spaces[action[1]]?.name,
      agrees: action[0] === 'space' && action[1] === trench.expected.id };
    fs.writeFileSync(__dirname + '/event-state-trench-' + seed + '.json', JSON.stringify(before, null, 2) + '\n');
  }
  g = R.action(g, role, ...action);
  if (example) {
    example.afterState = g.state;
    example.vpChange = g.vp - before.vp;
    example.restoredUnits = before.reduced.filter(id => !g.reduced.includes(id));
    if (action[0] === 'reset_phase') {
      example.afterFrom = unitsAt(g, example.from.id);
      example.afterTo = unitsAt(g, example.to.id);
      result.examples.movementReset = example;
    } else if (trench) result.examples.eventTrench = example;
    else result.examples[state] = example;
  }
  if (g.log.length > 400) g.log = g.log.slice(-100);
  result.steps++;
}
if (g.state !== 'game_over') throw Error('Incomplete game');
result.result = g.result;
fs.writeFileSync(__dirname + '/event-proof.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result.examples, null, 2));
