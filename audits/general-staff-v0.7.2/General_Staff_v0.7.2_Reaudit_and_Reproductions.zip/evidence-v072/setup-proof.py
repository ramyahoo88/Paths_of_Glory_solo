"""Exercise setup using an isolated, pre-existing local git cache fixture.

The fixture deliberately uses a local tag called c58b0b4. This tests file/link
handling and idempotence, not network fetching or provenance of that revision.
"""
import hashlib
import json
import pathlib
import shutil
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
SRC = ROOT / 'source-v072'
MARKER = b'// ---- Solo-bot harness hook (appended; not part of Rally the Troops) ----'


def run(argv, cwd):
    return subprocess.run(argv, cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()


results = []
for mode in ('absent_engine', 'dangling_engine_link'):
    with tempfile.TemporaryDirectory(prefix='general-staff-setup-') as tmp:
        root = pathlib.Path(tmp)
        sim = root / 'sim'
        cache = sim / 'rtt-pog'
        cache.mkdir(parents=True)
        for name in ('setup_engine.sh', 'engine_hook.js'):
            shutil.copyfile(SRC / 'sim' / name, sim / name)
        for name in ('data.js', 'lz4.js'):
            shutil.copyfile(SRC / 'engine' / name, cache / name)
        raw_rules = (SRC / 'engine/rules.js').read_bytes().split(MARKER)[0]
        (cache / 'rules.js').write_bytes(raw_rules)
        run(['git', 'init', '-q'], cache)
        run(['git', 'add', 'data.js', 'lz4.js', 'rules.js'], cache)
        run(['git', '-c', 'user.name=Setup fixture', '-c', 'user.email=fixture@example.invalid',
             'commit', '-q', '-m', 'Local cache fixture'], cache)
        run(['git', 'tag', 'c58b0b4'], cache)
        engine = root / 'engine'
        if mode == 'dangling_engine_link':
            engine.symlink_to(root / 'missing-target')
        outputs = []
        for _ in range(2):
            outputs.append(run(['sh', 'setup_engine.sh'], sim))
            assert engine.is_dir() and not engine.is_symlink()
            assert (engine / 'rules.js').read_bytes().count(MARKER) == 1
            assert (engine / 'data.js').read_bytes() == (cache / 'data.js').read_bytes()
            assert (engine / 'lz4.js').read_bytes() == (cache / 'lz4.js').read_bytes()
            assert run(['node', '-e', "if(typeof require('./engine/rules.js').__with!=='function')process.exit(1)"], root) == ''
        results.append({'mode': mode, 'runs': len(outputs), 'result': 'pass',
                        'rulesSHA256': hashlib.sha256((engine / 'rules.js').read_bytes()).hexdigest()})

out = {'scope': 'Local pre-existing cache fixture only, no network clone tested', 'results': results}
(ROOT / 'evidence-v072/setup-proof.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
