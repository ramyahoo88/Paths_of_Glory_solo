# General Staff v0.7.3 re-audit evidence

Reviewed production: ramyahoo88/Paths_of_Glory_solo, claude-bot, 2d8abad3ea8e3bdd430635739a122c63af70ab9e. Engine: Rally the Troops c58b0b4a33e227faf73cbe561f3bede17087a142 plus the repository's hook. The external engine and publisher downloads are excluded.

No production decision logic was changed. The two event findings are recorded with runnable assertions of their **observed v0.7.3 behavior**. A passing reproduction proves that the defect exists; it is not a corrected-behavior release test.

## Run

Obtain the reviewed checkout and run its `sim/setup_engine.sh`. Extract this archive anywhere. Set `GS_ROOT` to the absolute path of that checkout, or place it at `source` beside the extracted `evidence` folder. Run the following from the archive root:

```sh
export GS_ROOT=/absolute/path/to/Paths_of_Glory_solo
node evidence/event-boundaries.cjs
node evidence/event-proof.cjs
node evidence/fix-checks.cjs
node evidence/boundary-checks.cjs
node evidence/hidden-info-check.cjs
node evidence/mo-proof.cjs
python3 evidence/print-checks-v073.py
node "$GS_ROOT/app/test_companion.cjs"
node "$GS_ROOT/sim/tests/multinational.js"
python3 "$GS_ROOT/print/check_print.py"
```

Node is needed for JavaScript checks. Python with PyMuPDF is needed for PDF/content comparisons. The report builder additionally needs ReportLab and DejaVu fonts. Scripts write result files next to themselves. Full source acquisition/setup uses the repository's public Git sources.

## Files

- `event-boundaries.cjs`: four North/South event-tie counterexamples, Reserve Box controls, a minimal Salonika case reached from normal event selection, seed 1080055 replay, and preceding-audit event snapshots.
- `salonika-reached-1080055.json`: exact full engine state, current Staff card, offered actions and selected piece from turn 16 round 5, decision 2992. Recreate a Bot for its side, assign its `staff` to `bot.dir`, and call `decide(fixture.game, R.view(fixture.game, fixture.game.active))` to reproduce that choice without playing the earlier campaign.
- `salonika-contact-only.json`: minimal pre-transfer state for the same contact-only failure.
- `event-boundaries-results.json`: observed decisions and controls. `old-event-states/` contains the earlier audit's exact Landwehr, War in Africa and trench snapshots from seed 951000.
- `event-proof.cjs` and `event-proof.json`: current seed-951000 campaign observations. Unlike the older release, it finishes without a movement reset; named Landwehr/War in Africa and event-trench choices are recorded. A changed trajectory need not revisit the old move position.
- `fresh-self-120.json`: unmodified `STRICT=1 node sim/final_eval.js self 120 1080000` output (run from sim as documented in the report). Includes every seed, result, completion, decision count, stats, exceptions and fallback reason. `fresh-summary.json` aggregates it.
- `fix-checks.cjs`: independent 864-case arithmetic comparison and prior calculator/exception/step-cap checks.
- `boundary-checks.cjs`: native-rule setup, scoring, automatic endings, exhausted reserve, compulsory loss allocation, isolated supply and Tie checks.
- `hidden-info-check.cjs`: decision-time read traps for the opponent's hand, either strategy deck and engine RNG, seed 981000.
- `mo-proof.cjs`: four original MO regression seeds and selected-unit qualification checks.
- `print-checks-v073.py`: reference content parity and exact card-page checks. `rendered/` contains all 23 shipped PDF page images and extracted text.
- `build-check-v073.json`: separate-directory byte comparisons. To repeat, preserve the checkout, extract `git archive 2d8abad` elsewhere, link/copy its pinned engine directory, run `node app/build_app.js` and `NO_PDF=1 node print/build.js`, then compare the four HTML files with the preserved checkout.
- `sample-v073.md`: seed-2 two-turn sample rebuild; byte-identical to the shipped sample.
- `source-sha256.json`: source/artifact fingerprints. `coverage.txt` states the hosted access, browser and measurement limits.
- `make-report.py`: rebuilds the Markdown report at the archive root as a paginated PDF. PDF metadata may differ between runs; HTML reproducibility is the measured byte-level build claim.

## Limits and interpretation

Fresh self-play is 106 Allied / 14 CP wins, 120 completions, 374,567 decisions, zero exceptions and zero rule-violation resets. One ordinary decision uses generic fallback: the reached Salonika issue. These are bot opponents, not human playtests.

The historical published 740-game result set, earlier-reference A/B samples and handicap samples are not included or independently rerun. The source repository has their summary tables/scripts. Hosted access reached a sign-in page, so no hosted parity pass is claimed. No new local real-browser, phone or accessibility pass. Shipped PDFs were rendered directly; their regeneration was not repeated.
