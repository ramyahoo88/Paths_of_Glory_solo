const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {createRequire}=require('node:module');
const B=require((process.env.GS_ROOT||require('path').resolve(__dirname,'../source'))+'/sim/board.js');
const R=require((process.env.GS_ROOT||require('path').resolve(__dirname,'../source'))+'/engine/rules.js');
const {Bot}=require((process.env.GS_ROOT||require('path').resolve(__dirname,'../source'))+'/sim/bot.js');
const code=fs.readFileSync(path.join(process.env.GS_ROOT||path.resolve(__dirname,'../source'),'app/General_Staff_Companion.html'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const nodes={};
const values={acf:'3',dcf:'0',fort:'0',terr:'0',tr:'0',bmo:'0',bfront:'0',evq:''};
const el=id=>nodes[id]??={value:values[id]??'',checked:['aarmy','dunits'].includes(id),innerHTML:'',textContent:'',classList:{toggle(){}}};
const context=vm.createContext({document:{getElementById:el,querySelectorAll:()=>[]},window:{},localStorage:{getItem:()=>null,setItem(){}},Math});
vm.runInContext(code,context);
const app=vm.runInContext('({D,S,render,renderEdge})',context);
assert.deepEqual(Array.from(app.D.army),B.printedExpectedTable(R.__api.fire_table.army));
assert.deepEqual(Array.from(app.D.corps),B.printedExpectedTable(R.__api.fire_table.corps));
app.S.side='ap';app.S.cur=app.D.deck.find(c=>c.stance==='H').id;app.render();
assert(nodes.edge.innerHTML.includes('Edge +2.2'));
assert(nodes.edge.innerHTML.includes('too weak'));
const zeroCF=nodes.edge.innerHTML;
app.S.side='cp';app.S.cur=app.D.deck.find(c=>c.stance==='A').id;
nodes.acf.value='9';nodes.dcf.value='12';nodes.darmy.checked=true;
nodes.bnear.checked=true;nodes.bvp.checked=true;nodes.bfront.value='-0.25';
app.render();assert(nodes.edge.innerHTML.includes('Score +0.05'));assert(nodes.edge.innerHTML.includes(' — attack'));
const rounding=nodes.edge.innerHTML;
nodes.dunits.checked=false;nodes.darmy.checked=true;nodes.fort.value='2';nodes.dcf.value='0';nodes.acf.value='5';
nodes.bnear.checked=false;nodes.bvp.checked=false;nodes.bfront.value='0';nodes.tr.value='0';app.renderEdge();const emptyFort=nodes.edge.innerHTML;
for(const tr of ['1','2']){nodes.tr.value=tr;app.renderEdge();assert.equal(nodes.edge.innerHTML,emptyFort);}
let comparisons=0;
function col(table,cf,shift){let i=0;while(i+1<table.length&&table[i+1].factors<=cf)i++;return Math.max(0,Math.min(table.length-1,i+shift));}
for(const aArmy of [false,true])for(const dArmy of [false,true])for(const aCF of [1,3,6,9,12,16])for(const dCF of [0,1,3,6,9,12])for(const terrain of [0,1])for(const trench of [0,1,2]){
 const at=R.__api.fire_table[aArmy?'army':'corps'],dt=R.__api.fire_table[dArmy?'army':'corps'];
 const ah=B.printedExpectedTable(at)[col(at,aCF,-terrain-trench)],dh=B.printedExpectedTable(dt)[col(dt,dCF,trench?1:0)];
 nodes.aarmy.checked=aArmy;nodes.darmy.checked=dArmy;nodes.dunits.checked=true;
 nodes.acf.value=String(aCF);nodes.dcf.value=String(dCF);nodes.fort.value='0';nodes.terr.value=String(terrain);nodes.tr.value=String(trench);
 app.renderEdge();const expected=Math.round((ah-dh)*10)/10;
 const actual=Number(nodes.edge.innerHTML.match(/Edge ([+-]?[\d.]+)/)[1]);
 assert.equal(actual,expected);comparisons++;
}
const requireEval=createRequire(path.resolve(process.env.GS_ROOT||path.resolve(__dirname,'../source'),'sim/final_eval.js'));
const evalCode=fs.readFileSync(path.resolve(process.env.GS_ROOT||path.resolve(__dirname,'../source'),'sim/final_eval.js'),'utf8');
function runEval(strict,inject,cap){
 const original=Bot.prototype.decide;let fired=false,output;
 if(inject)Bot.prototype.decide=function(...args){if(!fired){fired=true;throw Error('GS04_RECHECK_INJECTED')}return original.apply(this,args);};
 const run=vm.compileFunction(cap===undefined?evalCode:evalCode.replace('const MAX_STEPS = 60000','const MAX_STEPS = '+cap),['require','process','console']);
 try{run(requireEval,{argv:['node','final_eval.js','self','1','976001'],env:{STRICT:strict?'1':'0'}},{log:text=>{output=JSON.parse(text);}});}finally{Bot.prototype.decide=original;}
 return output.games[0];
}
const regular=runEval(false,true);assert.equal(regular.exceptions.length,1);assert.equal(regular.exceptions[0].message,'GS04_RECHECK_INJECTED');assert(regular.complete);
const strict=runEval(true,true);assert(!strict.complete);assert(strict.err.includes('GS04_RECHECK_INJECTED'));
const capped=runEval(true,false,0);assert(!capped.complete);assert(capped.err.includes('step cap'));
const result={zeroCF,rounding,emptyFort,calculatorComparisons:comparisons,reporting:{normalMode:regular.exceptions,strictError:strict.err,stepCap:capped.err}};
fs.writeFileSync(__dirname+'/fix-checks.json',JSON.stringify(result,null,2)+'\n');console.log('Calculator and printed table parity:',comparisons,'cases; original examples, empty forts, exceptions, strict mode and step cap passed.');
