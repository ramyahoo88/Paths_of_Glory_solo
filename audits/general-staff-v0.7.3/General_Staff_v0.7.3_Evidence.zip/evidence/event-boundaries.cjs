// Independent v0.7.3 event-boundary reproductions. Production decision logic is unmodified.
// Usage: GS_ROOT=/path/to/checkout node event-boundaries.cjs
'use strict'
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../source'));
const R=require(path.join(root,'engine/rules.js')),B=require(path.join(root,'sim/board.js'));
const {Bot,ROLE,legal,makeDeck}=require(path.join(root,'sim/bot.js'));
const results={version:'0.7.3',commit:'2d8abad3ea8e3bdd430635739a122c63af70ab9e',checks:[],findings:{}};
function bot(tie='N'){const b=new Bot('ap',100);b.dir={id:3,n:1,stance:'H',plan:'L',tie};return b;}
function base(state){const g=R.setup(100,'Historical',{no_supply_warnings:true});g.location.fill(0);g.turn=5;g.active=ROLE.ap;g.state=state;g.ap.commitment='limited';g.war.tu=2;g.salonika_sr_remaining=3;g.war_in_africa_removed=0;return g;}
function named(g,ps){return ps.map(p=>({id:p,name:B.data.pieces[p].name,space:B.data.spaces[g.location[p]]?.name,location:g.location[p]}));}
// Both corps are out of contact, on the same front: the current Staff Tie must decide.
for(const state of ['war_in_africa','salonika'])for(const tie of ['N','S']){
 const g=base(state);g.location[156]=B.S('Port Said');g.location[157]=B.S('Alexandria');
 const b=bot(tie),v=R.view(g,g.active),a=b.decide(g,v);
 const expected=[156,157].sort((x,y)=>b.tie(g.location[x],g.location[y]))[0];
 assert(legal(v.actions,a));assert.notEqual(a[1],expected,'v0.7.3 reproduces the reversed tie');
 results.checks.push({state,tie,offered:named(g,v.actions.piece),expected,actual:a[1],agrees:false});
}
// The higher-priority Reserve Box choice still works.
for(const state of ['war_in_africa','salonika']){
 const g=base(state);g.location[156]=B.S('Port Said');g.location[157]=R.__api.AP_RESERVE_BOX;
 const b=bot(),a=b.decide(g,R.view(g,g.active));assert.deepEqual(a,['piece',157]);
 results.checks.push({state,control:'Reserve Box beats map corps',action:a,pass:true});
}
// The printed Salonika rule never sends a corps in contact. With one available corps in contact, event selection
// plays Salonika, its handler returns no choice, and the generic dispatcher transfers that corps anyway.
{
 let g=base('action_phase');g.ap.hand=[30];g.ap.actions=[];g.location[156]=B.S('Port Said');g.location[68]=B.S('Sinai');
 const b=bot(),trace=[];let saw=false;
 for(let i=0;i<8;i++){
  const v=R.view(g,g.active),before=structuredClone(g),a=b.decide(g,v);
  assert(legal(v.actions,a));trace.push({state:g.state,prompt:v.prompt,action:a});
  if(g.state==='salonika'){
   assert.equal(g.salonika_sr_remaining,3);assert.deepEqual(a,['piece',156]);
   assert(R.__with(g,A=>b.adjEnemy(A,g.location[156])));
   assert.equal(b.stats.fallback['nochoice:salonika'],1);
   results.findings.contactOnly={trace,contact:named(g,[156,68]),fallback:b.stats.fallback};
   fs.writeFileSync(path.join(__dirname,'salonika-contact-only.json'),JSON.stringify({game:before,side:b.side,staff:b.dir,action:a},null,2)+'\n');
   saw=true;break;
  }
  g=R.action(g,g.active,...a);
 }
 assert(saw);
}
// A normal fresh-seed full campaign reaches the same unsupported boundary; retain its exact board state.
{
 const seed=1080055;let g=R.setup(seed,'Historical',{no_supply_warnings:true}),steps=0,found=false;
 const P=Object.fromEntries(['ap','cp'].map(s=>[ROLE[s],new Bot(s,seed)]));
 while(g.state!=='game_over'&&steps<60000){
  const role=g.active,b=P[role],v=R.view(g,role),old=b.stats.fallback['nochoice:salonika']||0;
  const before=g.state==='salonika'?structuredClone(g):null,a=b.decide(g,v);
  assert(legal(v.actions,a));
  if((b.stats.fallback['nochoice:salonika']||0)>old){
   const fixture={seed,step:steps,turn:g.turn,side:b.side,staff:b.dir,state:g.state,prompt:v.prompt,actions:v.actions,action:a,units:named(g,v.actions.piece||[]),inContact:R.__with(g,A=>b.adjEnemy(A,g.location[a[1]])),fallback:{...b.stats.fallback},game:before};
   assert.equal(a[0],'piece');assert(fixture.inContact);assert.equal(g.salonika_sr_remaining,3);
   fs.writeFileSync(path.join(__dirname,'salonika-reached-1080055.json'),JSON.stringify(fixture,null,2)+'\n');
   results.findings.reachedSalonika={seed,step:steps,turn:g.turn,staff:b.dir,actions:v.actions,action:a,units:fixture.units,inContact:fixture.inContact};found=true;
  }
  g=R.action(g,role,...a);steps++;if(g.log.length>400)g.log=g.log.slice(-100);
 }
 assert.equal(g.state,'game_over');assert(found);results.campaign={seed,steps,result:g.result,vp:g.vp,turn:g.turn};
}
// Reuse the preceding audit's exact event states, independently of the changed trajectory of seed 951000.
for(const [name,side,staff]of [['landwehr','cp',null],['war_in_africa','ap',null],['trench','ap',makeDeck().find(c=>c.id===10)]]){
 const p=path.join(__dirname,'old-event-states','event-state-'+name+'-951000.json');if(!fs.existsSync(p))continue;
 const g=JSON.parse(fs.readFileSync(p,'utf8')),b=new Bot(side,951000);if(staff)b.dir=staff;
 const v=R.view(g,g.active),a=b.decide(g,v);assert(legal(v.actions,a));
 if(name==='landwehr')assert.deepEqual(a,['piece',7]);
 if(name==='war_in_africa')assert.equal(g.location[a[1]],R.__api.AP_RESERVE_BOX);
 if(name==='trench'){
  const expected=R.__with(g,A=>b.byFrontThenTie(A,v.actions.space)[0]);assert.deepEqual(a,['space',expected]);
 }
 results.checks.push({priorFixture:name,action:a,pass:true});
}
fs.writeFileSync(path.join(__dirname,'event-boundaries-results.json'),JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results,null,2));
