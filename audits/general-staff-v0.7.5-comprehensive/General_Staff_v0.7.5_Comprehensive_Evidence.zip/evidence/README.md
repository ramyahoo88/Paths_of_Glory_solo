# General Staff v0.7.5 comprehensive audit evidence

Audited branch `claude-bot` at `073c31c7362684ea61149333bfc0ba70f0010ccd`; production `cd648213326835fe32536688adc4755960137f46`. Engine pin `c58b0b4a33e227faf73cbe561f3bede17087a142`. The report describes findings, severity, source lines and limitations. None of these scripts changes production source.

Use a fresh clone of `ramyahoo88/Paths_of_Glory_solo`, check out the audited revision, then run `bash sim/setup_engine.sh` from its root. Node was 24.22.3. Python print/rebuild checks require PyMuPDF; PDF report generation also requires ReportLab and DejaVu fonts. Set `REPO` to an absolute path to that clone and `EVIDENCE` to this extracted directory. Use a Python executable with those libraries installed.

## Focused reproductions

```sh
node "$EVIDENCE/focused-proofs.cjs" "$REPO" "$EVIDENCE"
node "$EVIDENCE/companion-expanded.cjs" "$REPO" "$EVIDENCE"
node "$EVIDENCE/scoring-and-summary.cjs" "$REPO" "$EVIDENCE"
GS_ROOT="$REPO" node "$EVIDENCE/siege-boundaries.cjs"
GS_ROOT="$REPO" python "$EVIDENCE/print-checks-v075.py"
GS_ROOT="$REPO" python "$EVIDENCE/check-records.py"
python "$EVIDENCE/rebuild-release.py" "$REPO" /tmp/gs-audit-rebuild
```

`focused-proofs.cjs` asserts the **observed defects** in unchanged v0.7.5, including the opposite-outcome controls. It should stop passing after the relevant fixes. `companion-expanded.cjs` likewise includes assertions reproducing damaged-level acceptance. These are defect demonstrations, not a green release gate. They must be converted to desired-behavior assertions when implementing corrections.

Fixtures with a `game` member are complete native-engine simulation states. They are not companion import files: the companion does not hold a board position. `corps-siege-fixture.json` and `attack-tie-fixture.json` are small constructed states; `release-ap-unsafe.json` and `brusilov-trace-fixture.json` are actual campaign snapshots. The proof script supplies the relevant bot Staff card/current move/plan and demonstrates exact calls.

## Fresh batches

The runner takes repository, policy, changed side, number of games, starting seed, output filename, and optional `trace`. Other-side settings stay at the release defaults. It checks offered-action legality, opponent hand/deck and engine-RNG access, 18-card cycles, VP-log consistency and post-step unit supply. It does not substitute an action after a decision exception. Exceptions remain in the output.

```sh
node "$EVIDENCE/audit-run.cjs" "$REPO" release ap 80 1080900 release-ap.json
node "$EVIDENCE/audit-run.cjs" "$REPO" pressure ap 40 1080900 pressure-ap.json
node "$EVIDENCE/audit-run.cjs" "$REPO" pressure cp 40 1080900 pressure-cp.json
node "$EVIDENCE/audit-run.cjs" "$REPO" preservation ap 40 1080900 preservation-ap.json
node "$EVIDENCE/audit-run.cjs" "$REPO" preservation cp 40 1080900 preservation-cp.json
node "$EVIDENCE/audit-run.cjs" "$REPO" exploitation ap 40 1080900 exploitation-ap.json
node "$EVIDENCE/audit-run.cjs" "$REPO" exploitation cp 40 1080900 exploitation-cp.json
node "$EVIDENCE/audit-run.cjs" "$REPO" pressure cp 40 1080940 pressure-cp-confirmation.json
node "$EVIDENCE/audit-run.cjs" "$REPO" release ap 1 1080800 representative.json trace
node "$EVIDENCE/audit-run.cjs" "$REPO" release ap 1 1080907 supply-trace.json trace
node "$EVIDENCE/audit-run.cjs" "$REPO" release ap 1 1080927 brusilov-trace.json trace
```

The eight batch files total 360 game executions; 1080907 and 1080927 trace files replay seeds already in the release batch. The representative campaign is separate. `siege-boundaries.cjs` reruns the previously affected seed 1080569 in addition to its 38 controls. Do not count these different policy/seed combinations as independent random samples of a single win rate. Policy comparisons are paired by seed; later dice need not remain aligned after differing actions.

Full traces contain `actions`, per-round bot plans, and `final`. Each action has a zero-based `i`, turn, side, state, proposed action, new state, VP and newly added log entries. `scoring-and-summary.json` contains the strategy table, health totals, 17 scoring controls and final-board VP reconstructions. `checked-records.json` audits existing committed data; it is not a rerun of those thousands of games.

## Release and visual evidence

`rebuild.json` contains complete SHA-256 hashes for all four matching HTML outputs. `print-parity-v075.json` gives table/card counts. `print-inspection.json` lists every shipped PDF page inspected and hashes of the local renders. The shipped PDFs are already in the pinned repository; use the rebuild script to reproduce the renders. Publisher PDFs and the third-party engine are not included here.

`regressions.json` records commands and output for the five shipped test scripts. `companion-expanded-results.json` records 13,080 calculator cases and ten deck cycles. These use DOM/storage doubles, not an actual browser. The browser launch/access limitations are documented in the report; no browser screenshots or hosted-parity result are claimed.

`source-manifest.json` hashes the reviewed production files and authoritative rulebook download. `evidence-manifest.json` hashes the evidence contents. Original developer result files stay in the pinned Git repository, and the record checker reads them there.
