"""Rebuild into a separate directory, byte-compare HTML, render shipped PDFs. Requires PyMuPDF.
python rebuild-release.py REPO OUTPUT_DIR [REF]
"""
import hashlib,io,json,os,pathlib,subprocess,sys,tarfile
import fitz
repo=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve()
ref=sys.argv[3] if len(sys.argv)>3 else '073c31c7362684ea61149333bfc0ba70f0010ccd'
out.mkdir(parents=True,exist_ok=True);build=out/'rebuild';build.mkdir(exist_ok=True)
tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',ref],cwd=repo))).extractall(build,filter='data')
if not (build/'engine').exists():(build/'engine').symlink_to(repo/'engine',target_is_directory=True)
files=['app/General_Staff_Companion.html','print/out/rules.html','print/out/reference.html','print/out/staff_cards.html']
shipped={f:(build/f).read_bytes() for f in files};logs=[]
for cmd in [['node','app/build_app.js'],['node','print/build.js']]:
 p=subprocess.run(cmd,cwd=build,env={**os.environ,'NO_PDF':'1'},capture_output=True,text=True)
 logs.append(dict(command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0
rows=[]
for f in files:
 a=shipped[f];b=(build/f).read_bytes();assert a==b,f
 rows.append(dict(file=f,bytes=len(a),shipped=hashlib.sha256(a).hexdigest(),rebuilt=hashlib.sha256(b).hexdigest(),equal=True))
(out/'rebuild.json').write_text(json.dumps(dict(ref=ref,commands=logs,files=rows),indent=2))
rendered=out/'rendered';rendered.mkdir(exist_ok=True)
for name in ['rules','reference','staff_cards']:
 d=fitz.open(build/f'print/out/{name}.pdf')
 for i,p in enumerate(d):p.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(rendered/f'{name}-{i+1:02}.png')
print(json.dumps(rows,indent=2))
