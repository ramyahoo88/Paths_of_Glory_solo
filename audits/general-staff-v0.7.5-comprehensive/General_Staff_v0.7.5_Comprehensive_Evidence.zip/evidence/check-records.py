from pathlib import Path
from collections import Counter
import os,json,subprocess
root=Path(os.environ.get('GS_ROOT','/workspace/scratch/0f3d8162c9d6/general-staff-v075'));out=Path(__file__).resolve().parent;folder=root/'sim/results/v0.7.5'
cand='9c1326ebe290b9bc8ac90d3dff59a9955b5f0a8e';ref='bc8bef6ceb8311425accab2bfe2f7a8411548f55'
r={'candidate':cand,'reference':ref,'paired':{},'handicap':[]}
for p in sorted(folder.glob('paired_*.json')):
 d=json.loads(p.read_text());gs=d['games'];assert len(gs)==300;start=6001 if '6'in p.stem.split('_')[1] else 7001
 assert[g['seed']for g in gs]==list(range(start,start+300));assert d['candidate']['commit']==cand and d['reference']['commit']==ref
 ok=[g for g in gs if not g.get('error')];bad=[g for g in gs if g.get('error')];role='Allied Powers'if d['side']=='ap'else'Central Powers'
 for g in ok:assert g['result']in['Allied Powers','Central Powers'];assert g['candidateWin']==(g['result']==role)
 wins=sum(g['result']==role for g in ok);assert len(ok)==d['n'];assert round(wins/len(ok),3)==d['winRate'];assert len(bad)+sum(g['candidateDecisionErrors']for g in ok)==d['errs']
 r['paired'][p.name]={'attempts':len(gs),'completed':len(ok),'wins':wins,'winRate':d['winRate'],'errorGames':len(bad),'errorKinds':dict(Counter(g['error']for g in bad))}
for p in sorted(folder.glob('handicap_*.json')):
 d=json.loads(p.read_text());gs=d['games'];assert[g['seed']for g in gs]==list(range(30001,30151))
 ok=[g for g in gs if not g.get('error')];assert len(ok)==d['n']==150;assert d['errors']==0
 ap=sum(g['result']=='Allied Powers'for g in ok);cp=sum(g['result']=='Central Powers'for g in ok);assert ap+cp==150
 assert round(ap/150,3)==d['ap']and round(cp/150,3)==d['cp'];assert not any(g['substituted']for g in ok)
 r['handicap'].append({'shift':d['shift'],'startVP':d['startVP'],'games':len(gs),'ap':ap,'cp':cp,'hasCommitStamp':'candidate'in d or 'reference'in d})
gs=[g for pattern in ['self_*.json','rnd_*.json','naive_*.json']for p in sorted(folder.glob(pattern))for g in json.loads(p.read_text())['games']]
assert len(gs)==740;fb=Counter();resets=forced=exceptions=0
for g in gs:
 assert g['complete']and g['err']is None and not g['exceptions'];exceptions+=len(g['exceptions'])
 for side in ['ap','cp']:
  s=g['stats'][side];fb.update(s.get('fallback',{}));resets+=s.get('violations',0);forced+=s.get('salonikaForced',0)
assert not fb and resets==forced==exceptions==0
selfg=[g for p in sorted(folder.glob('self_*.json'))for g in json.loads(p.read_text())['games']];assert sorted(g['seed']for g in selfg)==list(range(1080000,1080600))
r['evaluation']={'games':len(gs),'selfGames':len(selfg),'selfWins':dict(Counter(g['result']for g in selfg)),'exceptions':exceptions,'fallback':dict(fb),'resets':resets,'salonikaForced':forced,'steps':sum(g['steps']for g in gs)}
core=['sim/bot.js','sim/board.js','sim/events.js','sim/ab.js','sim/vpshift.js','sim/play.js','sim/final_eval.js','sim/engine_hook.js','sim/setup_engine.sh']
subprocess.run(['git','diff','--exit-code',cand,'HEAD','--',*core],cwd=root,check=True,stdout=subprocess.DEVNULL)
r['coreMatchesPinnedCandidate']=core
(out/'checked-records.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
