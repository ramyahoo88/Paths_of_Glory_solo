'use strict';
// Defect reproductions for unmodified v0.7.5. PASS means the stated observation was reproduced.
// node focused-proofs.cjs REPO [EVIDENCE_DIR]
const fs=require('fs'),path=require('path'),assert=require('assert');
const repo=path.resolve(process.argv[2]),dir=path.resolve(process.argv[3]||__dirname);
const R=require(repo+'/engine/rules.js'),B=require(repo+'/sim/board.js'),{Bot,makeDeck}=require(repo+'/sim/bot.js');
const copy=x=>x===undefined?null:JSON.parse(JSON.stringify(x)),results=[];
const save=(name,x)=>fs.writeFileSync(path.join(dir,name),JSON.stringify(x,null,2));
const name=s=>B.data.spaces[s].name;
function base(){const g=R.setup(88,'Historical',{no_supply_warnings:true});g.location.fill(0);g.reduced=[];g.turn=3;g.cp.mo='none';g.cp.actions=[];g.active='Central Powers';g.state='action_phase';g.cp.hand=[69];return g;}
function update(g){R.__with(g,A=>A.update_supply());}

// First-step supply guard: the native game allows this move; General Staff §6 does not.
{
 const x=JSON.parse(fs.readFileSync(path.join(dir,'release-ap-unsafe.json'))),g=copy(x.game);
 const b=new Bot('ap',x.seed);b.dir=makeDeck()[0];b.curMove=copy(x.move);
 const view=R.view(g,g.active),a=b.decide(g,view);
 assert.deepStrictEqual(a,['space',B.S('Sofia')]);assert(!view.actions.stop);
 const before=R.__with(g,A=>g.move.pieces.map(p=>A.is_unit_supplied(p)));
 const next=R.action(g,g.active,...a);update(next);
 const after=R.__with(next,A=>[66,171].map(p=>A.is_unit_supplied(p)));
 assert.deepStrictEqual(before,[true,true]);assert.deepStrictEqual(after,[false,false]);
 results.push({id:'supply-first-step',seed:x.seed,turn:g.turn,from:'Skopje',to:'Sofia',pieces:[66,171],action:a,offered:view.actions,before,after});
 // Nearby control: staying in Serbia remains supplied even when cut off.
 const stay=copy(x.game);stay.location[66]=B.S('Valjevo');stay.location[171]=B.S('Valjevo');update(stay);
 assert(R.__with(stay,A=>A.is_unit_supplied(66)&&A.is_unit_supplied(171)));
 results.push({id:'supply-serbian-exception-control',at:'Valjevo',supplied:true});
 const open=copy(next);
 for(const n of ['Strumitsa','Salonika']){const s=B.S(n);open.control[s>>5]&=~(1<<(s&31));for(let p=1;p<open.location.length;p++)if(open.location[p]===s&&B.data.pieces[p]?.faction==='cp')open.location[p]=0;}
 open.events.salonika=open.turn;update(open);
 assert(R.__with(open,A=>A.is_unit_supplied(66)&&A.is_unit_supplied(171)));
 results.push({id:'supply-open-route-control',at:'Sofia',change:'Salonika event active; Allied-controlled empty Strumitsa and Salonika',supplied:true});
}

// A valid corps-only siege group cannot be formed if the alternative exit is blocked by an attack activation.
{
 let g=base();g.location[68]=g.location[69]=B.S('Mulhouse');g.location[70]=g.location[71]=g.location[72]=B.S('Strasbourg');update(g);
 const initial=copy(g),b=new Bot('cp',88);b.deck=[makeDeck()[2]];b.discard=[];
 const trace=[];let selection=null;
 for(let i=0;i<40;i++){
  const v=R.view(g,g.active),a=b.decide(g,v);
  if(g.state==='choose_pieces_to_move'&&g.move.initial===B.S('Mulhouse')&&!selection)selection=copy(g);
  trace.push({state:g.state,actions:v.actions,decision:a,move:copy(g.move),plan:copy(b.plan),violations:v.violations});
  const was=g.state;g=R.action(g,g.active,...a);
  if(was==='confirm_move_violations')break;
  if(g.active!=='Central Powers'||g.state==='game_over')break;
 }
 assert(trace.some(x=>x.state==='choose_pieces_to_move'&&x.decision[0]==='undo'));
 assert(trace.some(x=>x.state==='confirm_move_violations'&&x.decision[0]==='reset_phase'));
 assert.strictEqual(b.stats.violations,1);
 save('corps-siege-fixture.json',{game:initial,staff:makeDeck()[2]});save('corps-siege-trace.json',trace);
 // Control: the second corps IS available and the full two-corps group can legally besiege Belfort.
 assert(selection);const v=R.view(selection,selection.active);const second=v.actions.piece.find(p=>[68,69].includes(p));assert(second);
 const sel=R.action(selection,selection.active,'piece',second);assert.strictEqual(sel.move.pieces.length,2);
 const vv=R.view(sel,sel.active);assert(vv.actions.space.includes(B.S('Belfort')));
 assert(R.__with(sel,A=>A.can_besiege(B.S('Belfort'),sel.move.pieces)));
 const moved=R.action(sel,sel.active,'space',B.S('Belfort'));let v2=R.view(moved,moved.active);
 assert(!v2.violations?.length);assert.strictEqual(moved.location[68],B.S('Belfort'));assert.strictEqual(moved.location[69],B.S('Belfort'));assert(moved.forts.besieged.includes(B.S('Belfort')));
 results.push({id:'two-corps-siege',plan:trace[0].plan,decisions:trace.map(x=>[x.state,x.decision]),stats:b.stats,control:'selecting both corps manually legally enters Belfort'});
}

// An equal-CF attack-origin tie must use the Staff card's North/South order.
{
 const choices={};
 for(const tie of ['N','S']){
  const g=base();g.ap.trenches=[];g.location[1]=B.S('Metz');g.location[2]=B.S('Strasbourg');g.location[32]=B.S('Nancy');
  g.forts.destroyed=B.data.spaces.map((s,i)=>s?.fort&&i!==B.S('Nancy')?i:null).filter(x=>x!==null);update(g);
  const b=new Bot('cp',88);b.dir={...makeDeck()[0],tie};
  const plan=R.__with(g,A=>b.planOps(A,1));assert.strictEqual(plan.attacks[0].target,B.S('Nancy'));
  choices[tie]=plan.attacks[0].spaces.map(name);assert.deepStrictEqual(choices[tie],['Strasbourg']);
  if(tie==='N')save('attack-tie-fixture.json',{game:g,staff:b.dir,budget:1});
 }
 results.push({id:'attack-origin-tie',observed:choices,expected:{N:['Metz'],S:['Strasbourg']},mapY:{Metz:B.ycoord(B.S('Metz')),Strasbourg:B.ycoord(B.S('Strasbourg'))}});
}

// Same card changes the first front to East, but the siege handler uses numerical engine order.
{
 const g=base();g.state='siege_phase';g.phase='Siege Phase';const n=B.S('Nancy'),iv=B.S('Ivangorod');
 g.location[1]=n;g.location[2]=iv;g.forts.besieged=[n,iv].sort((a,b)=>a-b);g.sieges_to_roll=[...g.forts.besieged];update(g);
 assert(R.__with(g,A=>A.is_unit_supplied(1)&&A.is_unit_supplied(2)&&A.can_besiege(n,[1])&&A.can_besiege(iv,[2])));
 const b=new Bot('cp',88);b.dir=makeDeck()[9];const v=R.view(g,g.active),a=b.decide(g,v);
 assert(v.actions.space.includes(n)&&v.actions.space.includes(iv));assert.deepStrictEqual(a,['space',n]);
 const expected=R.__with(g,A=>b.byFrontThenTie(A,v.actions.space));assert.strictEqual(expected[0],iv);
 save('siege-order-fixture.json',{game:g,staff:b.dir});
 results.push({id:'siege-front-order',staff:b.dir,offered:v.actions.space.map(name),observed:name(a[1]),expected:name(expected[0]),fallbackCounter:b.stats.fallback});
}

// Brusilov's one-attack trench cancellation has no handler; the default passes.
{
 const x=JSON.parse(fs.readFileSync(path.join(dir,'brusilov-trace-fixture.json'))),g=copy(x.game),b=new Bot('ap',x.seed);b.dir=x.staff;
 const v=R.view(g,g.active),a=b.decide(g,v);assert.deepStrictEqual(a,['pass']);assert.strictEqual(b.stats.fallback['nohandler:brusilov_offensive_option'],1);
 const pass=R.action(copy(g),g.active,'pass'),use=R.action(copy(g),g.active,'use');
 assert(!pass.attack?.trenches_canceled);assert.strictEqual(use.attack.trenches_canceled,true);
 const defenders=R.__with(g,A=>A.get_pieces_in_space(g.attack.space).map(p=>B.data.pieces[p].name));
 results.push({id:'brusilov',seed:x.seed,turn:g.turn,round:g.ap.actions.length,target:name(g.attack.space),attackers:g.attack.pieces.map(p=>B.data.pieces[p].name),defenders,offered:v.actions,observed:a,passCanceled:!!pass.attack?.trenches_canceled,useCanceled:use.attack.trenches_canceled});
}
save('focused-proof-results.json',results);console.log(JSON.stringify(results,null,2));
