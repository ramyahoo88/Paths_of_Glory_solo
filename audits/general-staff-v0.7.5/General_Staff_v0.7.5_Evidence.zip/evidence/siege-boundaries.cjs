// Independent controls for the printed bot policy: preserve a besieging force, never abandon the siege for a move.
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../../general-staff-v075'));
const R=require(path.join(root,'engine/rules.js')),B=require(path.join(root,'sim/board.js'));
const {Bot}=require(path.join(root,'sim/bot.js'));
const cases=[];
for(const name of ['Antwerp','Nancy','Verdun'])for(const units of [[6],[73],[73,78],[6,73],[6,73,78],[68,73,78]]){
 let g=R.setup(100,'Historical',{no_supply_warnings:true});g.location.fill(0);g.turn=5;g.active='Central Powers';g.state='action_phase';const here=B.S(name);g.forts.besieged=[here];for(const p of units)g.location[p]=here;
 const b=new Bot('cp',100),level=B.data.spaces[here].fort;
 // Only fixtures that actually start with a legal siege.
 const initiallyLegal=units.some(p=>B.data.pieces[p].type==='army')||units.length>=level;if(!initiallyLegal)continue;
 for(const p of units){
  const rest=units.filter(q=>q!==p);const expected=rest.length>0&&(rest.some(q=>B.data.pieces[q].type==='army')||rest.filter(q=>B.data.pieces[q].type==='corps').length>=level);
  b.invalidate();const actual=R.__with(g,A=>b.siegeOk(A,here,[p]));assert.equal(actual,expected);
  cases.push({fort:name,level,units,leaving:[p],expected,actual});
 }
 if(!units.some(p=>{const rest=units.filter(q=>q!==p);return rest.length&&(rest.some(q=>B.data.pieces[q].type==='army')||rest.length>=level)})){
  const target=B.adj[here][0];b.invalidate();const first=R.__with(g,A=>b.hasFirstStep(A,{from:here,to:target,kind:'fill'}));assert.equal(first,false);
  cases.push({fort:name,units,check:'no legal departure drops move',pass:true});
 }
}
// The actual engine position, replayed through a complete campaign, must not trigger the formerly disclosed resets.
const seed=1080569;let g=R.setup(seed,'Historical',{no_supply_warnings:true}),steps=0;const P={'Allied Powers':new Bot('ap',seed),'Central Powers':new Bot('cp',seed)};
while(g.state!=='game_over'&&steps<60000){const v=R.view(g,g.active),b=P[g.active],a=b.decide(g,v);assert.notEqual(a[0],'reset_phase');g=R.action(g,g.active,...a);steps++;if(g.log.length>400)g.log=g.log.slice(-100);}
assert.equal(g.state,'game_over');const expected=JSON.parse(fs.readFileSync(path.join(root,'sim/results/v0.7.5/self_d.json'),'utf8')).games.find(x=>x.seed===seed);
for(const k of ['result','turn','vp'])assert.equal(g[k],expected[k]);assert.equal(steps,expected.steps);
const result={controls:cases.length,cases,campaign:{seed,result:g.result,turn:g.turn,vp:g.vp,steps,resets:0}};
fs.writeFileSync(path.join(__dirname,'siege-boundaries.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({controls:cases.length,campaign:result.campaign}));
