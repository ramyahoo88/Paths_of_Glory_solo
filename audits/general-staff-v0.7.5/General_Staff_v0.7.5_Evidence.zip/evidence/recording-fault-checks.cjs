// Execute the shipped recording scripts with injected failures, keeping production files unchanged.
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict'),{createRequire}=require('module');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../../general-staff-v075'));
const ref=path.resolve(process.env.GS_REF||path.join(__dirname,'../reference/sim'));
function execute(file,argv,hook){
 const filename=path.join(root,'sim',file),real=createRequire(filename);let output;
 const fake=p=>hook(p,real);const log=s=>{output=JSON.parse(s)};
 vm.compileFunction(fs.readFileSync(filename,'utf8'),['require','process','console','__dirname'])(fake,{argv:['node',filename,...argv],env:process.env},{log},path.dirname(filename));
 return output;
}
const ab=execute('ab.js',['ap','2','7001',ref,'{}'],(p,real)=>p==='./play.js'?{playGame(){throw Error('AUDIT_INJECTED_GAME_FAILURE')}}:real(p));
assert.equal(ab.errs,2);assert.equal(ab.n,0);assert.deepEqual(ab.games.map(g=>g.seed),[7001,7002]);assert(ab.games.every(g=>g.error==='AUDIT_INJECTED_GAME_FAILURE'));assert(ab.candidate.commit&&ab.reference.commit);
const handicap=execute('vpshift.js',['5','30001','30003'],(p,real)=>{
 if(p!=='./bot.js')return real(p);return{...real(p),Bot:class{decide(){throw Error('AUDIT_INJECTED_DECISION_FAILURE')}}};
});
assert.equal(handicap.errors,2);assert.equal(handicap.n,0);assert.deepEqual(handicap.games.map(g=>g.seed),[30001,30002]);assert(handicap.games.every(g=>g.error==='AUDIT_INJECTED_DECISION_FAILURE'));
assert(!handicap.candidate&&!handicap.reference,'reproduce the missing handicap commit stamps');
const r={ab,handicap,checks:['AB retains both failed seeds','AB stamps both source commits','handicap retains both failed seeds','handicap still has no candidate/reference commit metadata']};
fs.writeFileSync(path.join(__dirname,'recording-fault-checks.json'),JSON.stringify(r,null,2)+'\n');console.log('PASS recording failure checks; missing handicap commit metadata reproduced.');
