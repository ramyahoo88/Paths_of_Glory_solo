# General Staff v0.7.5 focused verification evidence

Reviewed production: ramyahoo88/Paths_of_Glory_solo, claude-bot, cd648213326835fe32536688adc4755960137f46. Recorded candidate: 9c1326ebe290b9bc8ac90d3dff59a9955b5f0a8e; reference: bc8bef6ceb8311425accab2bfe2f7a8411548f55. Simulation code is identical at candidate and reviewed production commits. Production decision logic was not edited.

Obtain the reviewed checkout and run its sim/setup_engine.sh. Extract this archive. From its root:

```sh
export GS_ROOT=/absolute/path/to/Paths_of_Glory_solo
node "$GS_ROOT/sim/tests/siege.js"
node "$GS_ROOT/sim/tests/event_choices.js"
node "$GS_ROOT/sim/tests/multinational.js"
node "$GS_ROOT/app/test_companion.cjs"
python3 "$GS_ROOT/print/check_print.py"
node evidence/siege-boundaries.cjs
python3 evidence/check-records.py
python3 evidence/print-checks-v075.py
```

For the paired replay and fault checks, prepare the reference worktree at bc8bef6 as instructed in the repository's results README. Replace its tracked engine symlink with a copy/link of the pinned engine first. Then set GS_REF to that worktree's sim folder:

```sh
export GS_REF=/absolute/path/to/reference/sim
node evidence/recording-fault-checks.cjs
```

The fault check intentionally reproduces the **remaining absent handicap commit metadata**. Passing that assertion confirms the v0.7.5 omission; it is not proof that EV-01 is fixed. It also confirms that both runners retain thrown failures as per-seed error records.

## Evidence

- siege-boundaries.cjs/json: 38 independent checks of fort levels 1/2/3, legal garrisons, unit departures and dropping moves. Also replays full seed 1080569 and asserts no reset, with exact result/VP/turn/decision-count agreement with its committed v0.7.5 record.
- siege-old-control.txt: the corrected shipped regression run against v0.7.4; it reproduces one reset and fails the no-reset assertion as expected. To repeat, give sim/tests/siege.js an old checkout's sim directory.
- fresh-48.json: unmodified `STRICT=1 node final_eval.js self 48 1080700` output, run from sim. These 48 seeds are outside the committed 600-game batch.
- check-records.py and checked-records.json: independent validation of all 740 evaluation records, twelve 300-attempt paired files and seven 150-game handicap files; aggregate checks; source-commit and seed-sequence checks; comparison of replayed samples. The checker also validates the additional 48 games.
- paired-ap-replay.json and paired-cp-replay.json: `node ab.js <side> 2 7001 "$GS_REF" '{}'` output, with each candidate side. Every game field matches the corresponding archived 9c1326e record.
- handicap-replay.json: `node vpshift.js 5 30001 30002`; game record matches its archived counterpart and the output demonstrates missing commit metadata.
- recording-fault-checks.cjs/json: unmodified script execution with injected game/decision failures; retains both requested seeds in each runner.
- build-check.json: four separate-path HTML rebuilds match the shipped HTML byte for byte. Repeat with a separate Git archive of cd64821, the pinned engine, `node app/build_app.js` and `NO_PDF=1 node print/build.js`, then compare with the preserved checkout.
- print-checks-v075.py: independent comparison of 36 Front Table cells, 110 event rows, 10 Objective rows, 19 expected-hit columns and every complete six-card face/back page. Requires PyMuPDF.
- rendered/: inspected booklet page 6 and reference page 1, containing the siege policy.
- source-sha256.json: reviewed source and artifact fingerprints.
- make-report.py: regenerates the report PDF from Markdown at the archive root; requires ReportLab and DejaVu fonts.

The paired and handicap games are recomputed from their committed records, with the five sampled records replayed. The complete paired/handicap batches were not independently rerun. Hosted parity, new real-browser/phone/accessibility checks, PDF regeneration and human strength tests are not claimed. External engine code and publisher downloads are excluded.
