// Observe the two disclosed fort-related resets without altering production decisions.
'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../../general-staff-v074'));
const R=require(path.join(root,'engine/rules.js')),B=require(path.join(root,'sim/board.js'));
const {Bot,ROLE,legal}=require(path.join(root,'sim/bot.js'));
const seed=1080569;let g=R.setup(seed,'Historical',{no_supply_warnings:true}),steps=0;
const P=Object.fromEntries(['ap','cp'].map(s=>[ROLE[s],new Bot(s,seed)]));const resets=[],recent=[];
while(g.state!=='game_over'&&steps<60000){
 const role=g.active,b=P[role],v=R.view(g,role),state=g.state;
 const before=state==='confirm_move_violations'?structuredClone(g):null;
 const a=b.decide(g,v);assert(legal(v.actions,a));
 recent.push({step:steps,state,action:a,move:g.move?structuredClone(g.move):null,curMove:b.curMove?structuredClone(b.curMove):null});if(recent.length>15)recent.shift();
 if(a[0]==='reset_phase'){
  const r={seed,step:steps,turn:g.turn,round:g[b.side].actions.length,side:b.side,violations:v.violations,staff:b.dir,curMove:b.curMove,affected:v.violations.map(x=>({space:B.data.spaces[x.space]?.name,fort:B.data.spaces[x.space]?.fort,units:B.data.pieces.flatMap((p,i)=>g.location[i]===x.space?[{id:i,name:p.name,type:p.type,faction:p.faction,reduced:g.reduced.includes(i)}]:[])})),recent:structuredClone(recent)};
  resets.push(r);fs.writeFileSync(path.join(__dirname,'reset-'+seed+'-'+resets.length+'.json'),JSON.stringify({game:before,proof:r},null,2)+'\n');
 }
 g=R.action(g,role,...a);steps++;if(g.log.length>400)g.log=g.log.slice(-100);
}
assert.equal(g.state,'game_over');assert.equal(resets.length,2);
const record=JSON.parse(fs.readFileSync(path.join(root,'sim/results/v0.7.4/self_d.json'),'utf8')).games.find(x=>x.seed===seed);
assert(record);assert.equal(record.result,g.result);assert.equal(record.vp,g.vp);assert.equal(record.steps,steps);
const r={seed,steps,result:g.result,vp:g.vp,turn:g.turn,resets};
fs.writeFileSync(path.join(__dirname,'reset-replay-summary.json'),JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify(r,null,2));
