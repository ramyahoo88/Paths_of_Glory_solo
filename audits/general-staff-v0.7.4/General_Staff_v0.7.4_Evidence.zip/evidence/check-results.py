"""Independently validate committed seed records and aggregate the fresh verification batch."""
from pathlib import Path
from collections import Counter
import os,json
root=Path(os.environ.get('GS_ROOT','/workspace/scratch/0f3d8162c9d6/general-staff-v074'))
out=Path(__file__).resolve().parent
r={}
for version in ['v0.7.3','v0.7.4']:
 folder=root/'sim/results'/version;games=[];files=[]
 for p in sorted(folder.glob('*.json')):
  x=json.loads(p.read_text());g=x.get('games',[])if isinstance(x,dict)else[]
  if not g:continue
  assert len(g)==x['n'];assert[x['seed']for x in g]==list(range(x['start'],x['start']+x['n']))
  for a in g:assert a['complete']is True and a['err']is None and not a['exceptions']
  files.append({'file':p.name,'games':len(g),'start':x['start']});games+=g
 selfgames=[g for p in sorted(folder.glob('self_*.json'))for g in json.loads(p.read_text())['games']]
 if version=='v0.7.4':assert sorted(g['seed']for g in games)==list(range(1080000,1080600))
 fallback=Counter();violations=[];forced=0
 for g in games:
  for side in ['ap','cp']:
   s=g['stats'][side];fallback.update(s.get('fallback',{}));forced+=s.get('salonikaForced',0)
   if s.get('violations'):violations.append({'seed':g['seed'],'side':side,'count':s['violations']})
 r[version]={'files':files,'games':len(games),'selfGames':len(selfgames),'selfWinners':dict(Counter(g['result']for g in selfgames)),'steps':sum(g['steps']for g in games),'fallback':dict(fallback),'salonikaForced':forced,'violations':violations,'pairedFiles':len(list(folder.glob('paired_*.json'))),'pairedFilesWithPerGameRecords':sum('games'in json.loads(p.read_text())for p in folder.glob('paired_*.json'))}
x=json.loads((out/'independent-fresh-48.json').read_text());games=x['games'];assert len(games)==48
assert[g['seed']for g in games]==list(range(1080600,1080648))
for g in games:
 assert g['complete']and g['err']is None and not g['exceptions']
 for side in ['ap','cp']:
  s=g['stats'][side];assert not s.get('fallback')and not s.get('salonikaForced')and not s.get('violations')
r['independentFresh']={'games':48,'seeds':[1080600,1080647],'steps':sum(g['steps']for g in games),'wins':dict(Counter(g['result']for g in games)),'exceptions':0,'unfinished':0,'fallback':0,'salonikaForced':0,'violations':0}
(out/'checked-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
