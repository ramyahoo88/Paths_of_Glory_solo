# General Staff v0.7.4 focused verification

Production reviewed: `ramyahoo88/Paths_of_Glory_solo`, `claude-bot`, `8cd287bdd85caef481ce280721b42185729c0d50`. Engine pinned to RTT c58b0b4 by the repository setup script. No production decision logic was changed.

Obtain that checkout and run `sim/setup_engine.sh`. Extract this archive and set GS_ROOT to the checkout's absolute path. From the extracted archive root:

```sh
export GS_ROOT=/absolute/path/to/Paths_of_Glory_solo
node "$GS_ROOT/sim/tests/event_choices.js"
node "$GS_ROOT/sim/tests/multinational.js"
node "$GS_ROOT/app/test_companion.cjs"
python3 "$GS_ROOT/print/check_print.py"
node evidence/independent-event-controls.cjs
node evidence/reset-replay.cjs
python3 evidence/print-checks-v074.py
python3 evidence/check-results.py
```

- `independent-event-controls.cjs/json`: 28 independent controls for actual offered transfer candidates, exclusions, contact/port/capacity gates, latest-front ordering, and stopping after the safe transfer.
- `reset-replay.cjs`: strict independent replay of disclosed seed 1080569; asserts two resets and matches the recorded final result, VP and decision count. `reset-1080569-1.json` and `-2.json` retain each full reached position and recent decision trace. Their game data is for the external rules engine, not a Companion import.
- `independent-fresh-48.json`: raw unmodified `STRICT=1 node final_eval.js self 48 1080600` output (run from the checkout's sim directory). Fresh seeds are disjoint from the committed 600-game batch.
- `check-results.py`: validates individual committed game sequences/completion and aggregates their health; separately checks all 48 additional games. `checked-results.json` is its output. It identifies the paired results as aggregates rather than individual game records.
- `build-check.json`: all four separate-directory HTML rebuilds and shipped SHA-256 values. Repeat by extracting `git archive 8cd287b` elsewhere, supplying the pinned engine, running `node app/build_app.js` and `NO_PDF=1 node print/build.js`, then comparing the four HTML files with the original checkout.
- `print-checks-v074.py`: independent comparisons of 36 Front Table cells, 110 event rows, 10 Objective rows, 19 expected-hit columns and each complete six-card face/back page. Requires PyMuPDF.
- `rendered/`: the two inspected PDF pages containing the changed event policy and event-list note.
- `source-sha256.json`: reviewed source/artifact fingerprints.
- `make-report.py`: rebuilds the report Markdown at the archive root as a PDF. Requires ReportLab and DejaVu fonts.

The archived games and tests supplement the repository's checks; they are not human strength measurements. The old paired and handicap results are aggregate only. No hosted Claude artifact parity, new real-browser/phone/accessibility pass, PDF regeneration or deployment is claimed. Engine code and publisher downloads are excluded.
