'use strict';
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=path.resolve(process.env.GS_ROOT||path.join(__dirname,'../../general-staff-v074'));
const R=require(path.join(root,'engine/rules.js')),B=require(path.join(root,'sim/board.js')),EP=require(path.join(root,'sim/events.js'));
const {Bot,ROLE}=require(path.join(root,'sim/bot.js'));
const checks=[];
function base(){const g=R.setup(100,'Historical',{no_supply_warnings:true});g.location.fill(0);g.turn=5;g.active=ROLE.ap;g.state='salonika';delete g.ap_mo_confirmation_needed;g.ap.commitment='limited';g.war.tu=2;g.ap.hand=[30];g.ap.actions=[];g.salonika_sr_remaining=3;g.war_in_africa_removed=0;return g;}
function bot(n=1,tie='N'){const b=new Bot('ap',100);b.dir={id:3,n,stance:'H',plan:'L',tie};return b;}
// Match the engine's actual offered transfers after applying the printed contact restriction.
for(const piece of [156,146,170,167,168,169,42])for(const where of ['Port Said','Reserve']){
 const g=base(),b=bot();g.location[piece]=where==='Reserve'?R.__api.AP_RESERVE_BOX:B.S(where);
 const offered=R.view(g,g.active).actions.piece||[],expected=[156,146].includes(piece)?[piece]:[];
 const actual=R.__with(g,A=>b.salonikaCandidates(A));assert.deepEqual(actual,expected);assert.deepEqual(actual,offered);
 checks.push({piece,name:B.data.pieces[piece].name,where,candidates:actual,pass:true});
}
for(const condition of ['contact','non-port','already at Salonika','full Salonika','no corps']){
 const g=base(),b=bot();
 if(condition!=='no corps')g.location[156]=B.S('Port Said');
 if(condition==='contact')g.location[68]=B.S('Sinai');
 if(condition==='non-port')g.location[156]=B.S('Cairo');
 if(condition==='already at Salonika')g.location[156]=B.S('Salonika');
 if(condition==='full Salonika')for(const p of [146,147,148])g.location[p]=B.S('Salonika');
 const candidates=R.__with(g,A=>b.salonikaCandidates(A)),priority=R.__with(g,A=>EP.priority(b,A,30));
 assert.deepEqual(candidates,[]);assert.equal(priority,0);checks.push({condition,candidates,priority,pass:true});
}
// Latest-front preference takes precedence over geography; changing the Staff front changes that ordering.
for(const state of ['war_in_africa','salonika'])for(const n of [1,6])for(const tie of ['N','S']){
 const g=base(),b=bot(n,tie);g.state=state;g.location[156]=B.S('Calais');g.location[157]=B.S('Port Said');
 const a=b.decide(g,R.view(g,g.active)),expected=n===1?157:156;
 assert.deepEqual(a,['piece',expected]);checks.push({state,staffFrontNumber:n,tie,action:a,pass:true});
}
// After sending the sole eligible Reserve Box corps, stop rather than sending the remaining corps in contact.
{
 let g=base();const b=bot();g.location[156]=R.__api.AP_RESERVE_BOX;g.location[157]=B.S('Port Said');g.location[68]=B.S('Sinai');
 let a=b.decide(g,R.view(g,g.active));assert.deepEqual(a,['piece',156]);g=R.action(g,g.active,...a);
 a=b.decide(g,R.view(g,g.active));assert.deepEqual(a,['done']);assert(!b.stats.salonikaForced);
 checks.push({condition:'one safe transfer then stop',action:a,pass:true});
}
fs.writeFileSync(path.join(__dirname,'independent-event-controls.json'),JSON.stringify({checks:checks.length,results:checks},null,2)+'\n');
console.log('PASS',checks.length,'independent event controls');
