const fs = require('node:fs');
const { Bot } = require('../source/sim/bot.js');
const original = Bot.prototype.decide;
const argv = process.argv;
const log = console.log;
let injected = false, captured;
Bot.prototype.decide = function (...args) {
  if (!injected) { injected = true; throw Error('AUDIT_TEST_INJECTED_DECISION_ERROR'); }
  return original.apply(this, args);
};
console.log = text => { captured = JSON.parse(text); };
process.argv = ['node', 'final_eval.js', 'self', '1', '948001'];
try { require('../source/sim/final_eval.js'); }
finally { Bot.prototype.decide = original; console.log = log; process.argv = argv; }
const game = captured.games[0];
const proof = { injected, result: game.result, reportedErr: game.err,
  apErrors: game.stats.ap.errors ?? null, cpErrors: game.stats.cp.errors ?? null };
fs.writeFileSync(__dirname + '/error-reporting-proof.json', JSON.stringify(proof, null, 2) + '\n');
console.log(proof);
