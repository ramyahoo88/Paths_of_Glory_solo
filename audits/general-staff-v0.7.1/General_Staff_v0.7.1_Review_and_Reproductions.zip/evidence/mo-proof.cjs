const fs=require('node:fs');
const R=require('../source/engine/rules.js');
const {Bot,ROLE,legal}=require('../source/sim/bot.js');
const B=require('../source/sim/board.js');
const original=Bot.prototype._actionPhase;
const cases=[];
Bot.prototype._actionPhase=function(A,g,acts){
 const choice=original.call(this,A,g,acts);
 if(['play_ops','single_op'].includes(choice[0])){
  for(const a of this.plan?.attacks??[]){
   if(!a.mo)continue;
   const pieces=a.spaces.flatMap(s=>this.attackersFrom(A,s,a.target));
   if(A.satisfies_mo(g[this.side].mo,pieces,this.enemyUnitsAt(A,a.target),a.target))continue;
   const proof={seed:g._auditSeed,turn:g.turn,round:g[this.side].actions.length+1,side:this.side,mandate:g[this.side].mo,
    step:this.step,choice,card:choice[1]&&B.data.cards[choice[1]].name,staff:this.dir,
    target:B.data.spaces[a.target].name,origins:a.spaces.map(s=>B.data.spaces[s].name),
    units:pieces.map(p=>B.data.pieces[p].name),score:a.score,edge:a.edge,
    need:this.minEdge(),moFlag:a.mo};
   cases.push(proof);
   fs.writeFileSync(__dirname+'/mo-selected-'+g._auditSeed+'-'+g.turn+'-'+proof.round+'.json',JSON.stringify({proof,game:g},null,2));
  }
 }
 return choice;
};
for(const seed of [931003,932003,933005,934000]){
 let g=R.setup(seed,'Historical',{no_supply_warnings:true});g._auditSeed=seed;
 const players={ap:new Bot('ap',seed),cp:new Bot('cp',seed)};
 let step=0;
 while(g.state!=='game_over'&&step++<60000){
  const side=g.active===ROLE.ap?'ap':'cp',v=R.view(g,g.active),action=players[side].decide(g,v);
  if(!legal(v.actions,action))throw Error('Illegal action');
  g=R.action(g,g.active,...action);g._auditSeed=seed;
  if(g.log.length>400)g.log=g.log.slice(-100);
 }
}
fs.writeFileSync(__dirname+'/mo-selected-summary.json',JSON.stringify(cases,null,2)+'\n');
console.log(JSON.stringify(cases,null,2));
