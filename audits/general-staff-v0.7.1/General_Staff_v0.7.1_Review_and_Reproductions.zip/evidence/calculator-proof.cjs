const fs=require('node:fs');
const vm=require('node:vm');
const R=require('../source/engine/rules.js');
const html=fs.readFileSync(__dirname+'/companion-original.html','utf8');
const code=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const nodes={};
const val={acf:'3',dcf:'0',fort:'0',terr:'0',tr:'0',bmo:'0',bfront:'0',evq:''};
const element=id=>nodes[id]??=( {value:val[id]??'',checked:id==='aarmy',innerHTML:'',textContent:'',classList:{toggle(){}}} );
const ctx=vm.createContext({document:{getElementById:element,querySelectorAll:()=>[]},window:{},localStorage:{getItem:()=>null,setItem(){}},Math});
vm.runInContext(code,ctx);
vm.runInContext("S.side='ap'; S.cur=D.deck.find(c=>c.stance==='H').id; render();",ctx);
const zeroCF=nodes.edge.innerHTML;
const table=R.__api.fire_table;
const expected=type=>table[type].map(c=>c.result.reduce((a,b)=>a+b)/6);
const thresholds=[0,.75,1.5,1,1.75,2.5];
const example=[];
for(const attacker of ['army','corps'])for(const defender of ['army','corps']){
 for(const [i,a]of expected(attacker).entries())for(const [j,d]of expected(defender).entries()){
  for(const objective of [0,.4,1])for(const vp of [0,.5])for(const oos of [0,.5])for(const front of [0,-.25,-.5,-.75,-1]){
   const bonus=objective+vp+oos+front;
   const exact=a-d+bonus;
   const printed=Number(a.toFixed(1))-Number(d.toFixed(1))+bonus;
   for(const need of thresholds)if((exact+1e-9>=need)!==(printed+1e-9>=need)){
    const result={attacker,attackingCF:table[attacker][i].factors,defender,defendingCF:table[defender][j].factors,
     attackHits:a,defenseHits:d,bonus:{objective,vp,oos,front},need,exact,printed};
    if(example.length<5)example.push(result);
   }
  }
 }
}
const result={zeroCF:{companion:zeroCF,expectedDefenseFire:expected('corps')[0],expectedEdge:expected('army')[2]-expected('corps')[0]},printedRounding:example};
fs.writeFileSync(__dirname+'/calculator-proof.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
