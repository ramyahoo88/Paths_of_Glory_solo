const fs = require('node:fs');
const path = require('node:path');
const R = require('../source/engine/rules.js');
const { Bot, ROLE, legal } = require('../source/sim/bot.js');
const B = require('../source/sim/board.js');
const originalPlan = Bot.prototype.planOps;
let record;
Bot.prototype.planOps = function(A, ...args) {
  const plan = originalPlan.call(this, A, ...args);
  for (const attack of plan.attacks.filter(a => a.mo)) {
    const pieces = attack.spaces.flatMap(s => this.attackersFrom(A, s, attack.target));
    const satisfies = A.satisfies_mo(A.game[this.side].mo, pieces, this.enemyUnitsAt(A, attack.target), attack.target);
    if (!satisfies) {
      const example = { seed: record.seed, turn:A.game.turn, round:A.game[this.side].actions.length+1,
        side:this.side, mo:A.game[this.side].mo, target:B.data.spaces[attack.target].name,
        spaces:attack.spaces.map(s=>B.data.spaces[s].name), units:pieces.map(p=>B.data.pieces[p].name) };
      const key=JSON.stringify(example);
      record.moMismatch[key]=example;
      if (!record.firstMoState) record.firstMoState=JSON.stringify(A.game);
    }
  }
  return plan;
};
const n=Number(process.argv[2]), start=Number(process.argv[3]);
const records=[];
for(let seed=start;seed<start+n;seed++) {
 let g=R.setup(seed,'Historical',{no_supply_warnings:true});
 const players=Object.fromEntries(['ap','cp'].map(s=>[ROLE[s],new Bot(s,seed)]));
 record={seed,moMismatch:{},states:{},steps:0,error:null};
 try {
  while(g.state!=='game_over'&&record.steps<60000) {
   const state=g.state,role=g.active,view=R.view(g,role);
   record.states[state]=(record.states[state]??0)+1;
   const action=players[role].decide(g,view);
   if(!legal(view.actions,action))throw Error('Returned illegal action '+JSON.stringify(action));
   g=R.action(g,role,...action);
   if(g.log.length>400)g.log=g.log.slice(-100);
   record.steps++;
  }
  if(g.state!=='game_over')throw Error('Step cap reached without game end');
 }catch(error){record.error=error.stack;}
 record.result=g.result;record.turn=g.turn;record.vp=g.vp;
 record.missed={ap:g.ap.missed_mo?.length??0,cp:g.cp.missed_mo?.length??0};
 record.stats=Object.fromEntries(['ap','cp'].map(s=>[s,players[ROLE[s]].stats]));
 if(record.firstMoState) {
  const filename=path.join(__dirname,'mo-state-'+seed+'.json');
  fs.writeFileSync(filename,record.firstMoState);
  record.firstMoState=path.basename(filename);
 }
 records.push(record);
}
fs.writeFileSync(path.join(__dirname,'audit-'+start+'.json'),JSON.stringify(records,null,2)+'\n');
console.log(start,records.length,'finished',records.filter(r=>!r.error).length,'MO plan mismatches',records.reduce((s,r)=>s+Object.keys(r.moMismatch).length,0));
